#!/usr/bin/env python3
"""Train from a reviewed dataset using a locally installed, licensed checkpoint."""
import argparse, hashlib, json, subprocess, sys
from pathlib import Path
def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument("dataset",type=Path)
    p.add_argument("--epochs",type=int,default=100); p.add_argument("--imgsz",type=int,default=640)
    p.add_argument("--batch",type=int,default=8); p.add_argument("--model",required=True)
    p.add_argument("--output",type=Path,default=Path("runs/contractors")); p.add_argument("--export",action="store_true")
    a=p.parse_args()
    if min(a.epochs,a.imgsz,a.batch)<1: p.error("training values must be positive")
    checkpoint=Path(a.model)
    if not checkpoint.is_file(): print("Checkpoint must already exist locally; automatic downloads are disabled."); return 2
    manifest=a.dataset/"dataset_manifest.json"
    if not manifest.is_file(): print("Missing dataset_manifest.json"); return 2
    validator=Path(__file__).with_name("validate_dataset.py")
    check=subprocess.run([sys.executable,str(validator),str(a.dataset)])
    if check.returncode: return check.returncode
    try:
        import yaml
        from ultralytics import YOLO
    except ImportError: print("Install the pinned optional training requirements."); return 2
    data=json.loads(manifest.read_text(encoding="utf-8"))
    names=[x["name"] if isinstance(x,dict) else x for x in data["classes"]]
    a.output.mkdir(parents=True,exist_ok=True)
    config={"path":str(a.dataset.resolve()),"train":"images/train","val":"images/val","test":"images/test","names":names}
    yaml_path=a.output/"dataset.yaml"; yaml_path.write_text(yaml.safe_dump(config,sort_keys=False),encoding="utf-8")
    result=YOLO(str(checkpoint)).train(data=str(yaml_path),epochs=a.epochs,imgsz=a.imgsz,batch=a.batch,project=str(a.output),name="run",exist_ok=True)
    best=Path(result.save_dir)/"weights"/"best.pt"
    if not best.is_file(): print("Training did not produce best.pt"); return 1
    record={"checkpoint":str(best),"checkpoint_sha256":hashlib.sha256(best.read_bytes()).hexdigest(),
      "dataset_manifest_sha256":hashlib.sha256(manifest.read_bytes()).hexdigest(),"epochs":a.epochs,
      "imgsz":a.imgsz,"batch":a.batch,"classes":names}
    (Path(result.save_dir)/"training_manifest.json").write_text(json.dumps(record,indent=2)+"\n")
    print("Training complete:",best)
    if a.export:
        exported=YOLO(str(best)).export(format="tflite",imgsz=a.imgsz)
        print("TFLite candidate:",exported)
        print("Not yet Task Vision compatible until metadata/output contract is verified and Quest load succeeds.")
    return 0
if __name__=="__main__": raise SystemExit(main())
