#!/usr/bin/env python3
"""Local OpenCV bounding-box annotator. No data leaves this computer."""
import argparse
from pathlib import Path
EXTS={".jpg",".jpeg",".png",".bmp",".webp"}
def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument("images",type=Path); p.add_argument("labels",type=Path)
    p.add_argument("--classes",nargs="+",required=True); a=p.parse_args()
    try: import cv2
    except ImportError: print("Install requirements-training.txt"); return 2
    files=sorted(x for x in a.images.iterdir() if x.suffix.lower() in EXTS)
    if not files: print("No images found"); return 1
    a.labels.mkdir(parents=True,exist_ok=True)
    for path in files:
        image=cv2.imread(str(path))
        if image is None: print("Unreadable:",path); continue
        h,w=image.shape[:2]; boxes=[]; selected=0; current=None; drawing=False; start=(0,0)
        win="LVL PLAY | drag box | 0-9 class | u undo | s save | n skip | q quit"
        def mouse(event,x,y,flags,param):
            nonlocal drawing,start,current
            if event==cv2.EVENT_LBUTTONDOWN: drawing=True; start=(x,y); current=(start,start)
            elif event==cv2.EVENT_MOUSEMOVE and drawing: current=(start,(x,y))
            elif event==cv2.EVENT_LBUTTONUP and drawing:
                drawing=False; current=None; x1,x2=sorted((start[0],x)); y1,y2=sorted((start[1],y))
                if x2-x1>=3 and y2-y1>=3: boxes.append((selected,(x1,y1,x2,y2)))
        cv2.namedWindow(win); cv2.setMouseCallback(win,mouse)
        while True:
            canvas=image.copy()
            for cls,(x1,y1,x2,y2) in boxes:
                cv2.rectangle(canvas,(x1,y1),(x2,y2),(0,255,0),2); cv2.putText(canvas,a.classes[cls],(x1,max(18,y1-4)),cv2.FONT_HERSHEY_SIMPLEX,.5,(0,255,0),1)
            if current: cv2.rectangle(canvas,current[0],current[1],(0,200,255),2)
            cv2.putText(canvas,f"{path.name} | class {selected}: {a.classes[selected]}",(8,22),cv2.FONT_HERSHEY_SIMPLEX,.55,(255,255,255),2)
            cv2.imshow(win,canvas); key=cv2.waitKey(20)&255
            if 48<=key<=57 and key-48<len(a.classes): selected=key-48
            elif key==ord("u") and boxes: boxes.pop()
            elif key==ord("s"):
                lines=[]
                for cls,(x1,y1,x2,y2) in boxes:
                    lines.append(f"{cls} {((x1+x2)/2)/w:.6f} {((y1+y2)/2)/h:.6f} {(x2-x1)/w:.6f} {(y2-y1)/h:.6f}")
                (a.labels/(path.stem+".txt")).write_text("\n".join(lines)+("\n" if lines else ""),encoding="utf-8")
                print("Saved",len(boxes),"boxes for",path.name); break
            elif key==ord("n"): print("Skipped",path.name); break
            elif key==ord("q"): cv2.destroyAllWindows(); return 0
        cv2.destroyAllWindows()
    return 0
if __name__=="__main__": raise SystemExit(main())
