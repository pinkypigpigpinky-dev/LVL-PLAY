#!/usr/bin/env python3
"""Validate a permission-cleared YOLO-format visual dataset using only Python stdlib.

Expected layout:
  dataset/
    dataset_manifest.json
    images/{train,val,test}/*
    labels/{train,val,test}/*.txt

Each non-empty label line: class_id x_center y_center width height
Coordinates are normalized to [0, 1]. Empty label files represent valid
negative images. This tool validates data hygiene; it does not train a model.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

SPLITS = ("train", "val", "test")
IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".bmp"}


def fail(errors: list[str], message: str) -> None:
    errors.append(message)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("dataset", type=Path, help="Dataset root directory")
    args = parser.parse_args()
    root = args.dataset.resolve()
    errors: list[str] = []
    warnings: list[str] = []

    manifest_path = root / "dataset_manifest.json"
    if not manifest_path.is_file():
        print("ERROR: missing dataset_manifest.json")
        return 2
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except Exception as exc:
        print(f"ERROR: invalid dataset_manifest.json: {exc}")
        return 2

    for key in ("dataset_name", "rights_owner", "permission_basis", "license", "source_notes"):
        if not str(manifest.get(key, "")).strip():
            fail(errors, f"manifest field '{key}' must be a non-empty string")
    classes = manifest.get("classes")
    if not isinstance(classes, list) or not classes:
        fail(errors, "manifest 'classes' must be a non-empty list")
        classes = []
    class_names: list[str] = []
    for i, item in enumerate(classes):
        name = item.get("name") if isinstance(item, dict) else item
        if not isinstance(name, str) or not name.strip():
            fail(errors, f"classes[{i}] must have a non-empty name")
        else:
            class_names.append(name.strip())
    if len(set(class_names)) != len(class_names):
        fail(errors, "class names must be unique")

    seen_hashes: dict[str, str] = {}
    total_images = 0
    total_boxes = 0
    split_counts: dict[str, int] = {}
    for split in SPLITS:
        image_dir = root / "images" / split
        label_dir = root / "labels" / split
        if not image_dir.is_dir():
            fail(errors, f"missing directory: images/{split}")
            continue
        if not label_dir.is_dir():
            fail(errors, f"missing directory: labels/{split}")
            continue
        images = sorted(p for p in image_dir.rglob("*") if p.is_file() and p.suffix.lower() in IMAGE_EXTS)
        split_counts[split] = len(images)
        total_images += len(images)
        if not images:
            warnings.append(f"images/{split} contains no images")
        expected_labels = {p.relative_to(image_dir).with_suffix(".txt") for p in images}
        for image_path in images:
            rel = image_path.relative_to(image_dir)
            label_path = label_dir / rel.with_suffix(".txt")
            digest = hashlib.sha256(image_path.read_bytes()).hexdigest()
            prior = seen_hashes.get(digest)
            if prior:
                fail(errors, f"duplicate image content across splits: {prior} and {split}/{rel}")
            else:
                seen_hashes[digest] = f"{split}/{rel}"
            if not label_path.is_file():
                fail(errors, f"missing label file for {split}/{rel}; use an empty .txt for a negative image")
                continue
            for line_no, line in enumerate(label_path.read_text(encoding="utf-8").splitlines(), 1):
                parts = line.split()
                if len(parts) != 5:
                    fail(errors, f"{label_path.relative_to(root)}:{line_no}: expected 5 fields, got {len(parts)}")
                    continue
                try:
                    class_id = int(parts[0])
                    coords = [float(v) for v in parts[1:]]
                except ValueError:
                    fail(errors, f"{label_path.relative_to(root)}:{line_no}: non-numeric label value")
                    continue
                if class_id < 0 or class_id >= len(class_names):
                    fail(errors, f"{label_path.relative_to(root)}:{line_no}: class id {class_id} outside 0..{len(class_names)-1}")
                if any(v < 0.0 or v > 1.0 for v in coords):
                    fail(errors, f"{label_path.relative_to(root)}:{line_no}: coordinates must be normalized to [0,1]")
                if coords[2] <= 0 or coords[3] <= 0:
                    fail(errors, f"{label_path.relative_to(root)}:{line_no}: box width and height must be positive")
                total_boxes += 1
        actual_labels = {p.relative_to(label_dir) for p in label_dir.rglob("*.txt")}
        for orphan in sorted(actual_labels - expected_labels):
            fail(errors, f"orphan label without matching image: labels/{split}/{orphan}")

    if total_images == 0:
        fail(errors, "dataset contains no supported images")
    if split_counts.get("train", 0) == 0 or split_counts.get("val", 0) == 0:
        fail(errors, "both train and val splits must contain images before training")
    if split_counts.get("test", 0) == 0:
        warnings.append("test split is empty; reserve an untouched test set before reporting final metrics")

    print(f"Dataset: {manifest.get('dataset_name', root.name)}")
    print(f"Classes ({len(class_names)}): {', '.join(class_names)}")
    for split in SPLITS:
        print(f"{split:>5}: {split_counts.get(split, 0)} images")
    print(f"Total: {total_images} images, {total_boxes} labeled boxes")
    for warning in warnings:
        print(f"WARNING: {warning}")
    for error in errors:
        print(f"ERROR: {error}")
    if errors:
        print(f"RESULT: FAIL ({len(errors)} errors)")
        return 1
    print("RESULT: PASS (structural checks only; not a model-quality or rights determination)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
