# LVL PLAY Contractors vision tools

All footage, labels, checkpoints, and training remain on your computer. Scripts do not upload footage or automatically download model weights.

## TF2 transfer-learning source (not Contractors footage)

A public Roboflow Universe listing exists for **Team Fortress 2 Classes**, version 5: 2,215 images, with a page-level license label of Public Domain. [Inspect the dataset listing](https://universe.roboflow.com/vinicius-soares/team-fortress-2-classes/dataset/5). That label alone does not establish rights to Valve-owned game imagery or guarantee that every image has clear provenance. Review the dataset creator's terms and underlying game-content rights before downloading, training, or redistributing anything. The listing describes an image dataset, not a permission-cleared raw video corpus.

TF2 is visually stylized and differs substantially from Contractors. It can be a **transfer-learning / pipeline smoke-test source** for generic character-like and object-like visual patterns, not ground truth for Contractors weapons, HUD, factions, maps, or tactical behavior. Never report TF2 test metrics as Contractors performance.

If you independently obtain a permitted YOLO-format export, map its exact source class names into LVL PLAY's generic target classes using a JSON file:

    {"source class exact name":"player_character","another source class":null}

Then import:

    python tools/contractors_vision/import_yolo_dataset.py ./tf2-export ./tf2-transfer --mapping ./tf2-class-map.json --dataset-name "TF2 transfer experiment" --rights-owner "REVIEWED RIGHTS HOLDER" --permission-basis "DOCUMENTED PERMISSION" --license "VERIFIED LICENSE" --source-notes "TF2 dataset version and provenance"

The importer never downloads the dataset and requires you to supply rights/provenance statements. Those statements are not independently verified. Review class names and annotations manually. Keep TF2 experiment outputs separate from any Contractors dataset and model.

## Prepare and annotate your own footage

Create the dataset layout and provenance manifest described in DATASET_SCHEMA.md. Split by complete recording session, never by adjacent frames.

    python tools/contractors_vision/extract_frames.py recording.mp4 review/session_001 --session session_001 --interval 1.0

Move all frames from that recording into one split. Install optional local tools:

    pip install -r tools/contractors_vision/requirements-training.txt

Annotate one split at a time:

    python tools/contractors_vision/annotate_yolo.py dataset/images/train dataset/labels/train --classes player_character weapon projectile objective_marker hud_marker

Drag boxes; press 0-9 to select a class, u to undo, s to save (an empty label is a reviewed negative), n to skip, q to quit. Review annotations manually.

## Validate, train, evaluate

    python tools/contractors_vision/validate_dataset.py ./dataset

Training requires a legally usable checkpoint already stored locally:

    python tools/contractors_vision/train_yolo.py ./dataset --model ./weights/licensed-model.pt --epochs 100 --imgsz 640 --batch 8 --export

Evaluate only against the untouched test split:

    python tools/contractors_vision/evaluate_yolo.py ./dataset runs/contractors/run/weights/best.pt

Training writes checkpoint and dataset-manifest hashes. TFLite export is only a candidate: export does not guarantee the metadata and output tensor contract required by Android TensorFlow Lite Task Vision. Inspect it and load it through the app's actual detector before integration.

## Release gate

Report per-class precision, recall, AP, false positives per minute, misses by map/range/lighting/motion blur/UI state, export parity, and sustained Quest latency/memory/thermal behavior. Test long negative clips as well as crowded scenes. No enemy/ally/hostility inference is supported by these object classes. Do not call a model Quest-ready until the app loads it and physical headset tests pass.
