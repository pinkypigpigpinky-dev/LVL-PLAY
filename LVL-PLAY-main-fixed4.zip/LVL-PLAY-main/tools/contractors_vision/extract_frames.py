#!/usr/bin/env python3
"""Extract frames from a locally owned gameplay video. OpenCV is optional."""
import argparse, hashlib, json
from pathlib import Path

def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument("video",type=Path); p.add_argument("output",type=Path)
    p.add_argument("--session",required=True); p.add_argument("--interval",type=float,default=1.0); p.add_argument("--max-frames",type=int,default=0)
    a=p.parse_args()
    if a.interval<=0: p.error("--interval must be positive")
    try: import cv2
    except ImportError: print("Install tools/contractors_vision/requirements-training.txt"); return 2
    if not a.video.is_file(): p.error("video does not exist")
    cap=cv2.VideoCapture(str(a.video))
    if not cap.isOpened(): print("Cannot open video"); return 2
    a.output.mkdir(parents=True,exist_ok=True); fps=cap.get(cv2.CAP_PROP_FPS) or 30.0
    count=cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0
    manifest={"source_video":a.video.name,"source_sha256":hashlib.sha256(a.video.read_bytes()).hexdigest(),
      "session_id":a.session,"fps":fps,"duration_seconds":count/fps if count else 0,"interval_seconds":a.interval,"frames":[]}
    t=0.0; saved=0
    while not a.max_frames or saved<a.max_frames:
        cap.set(cv2.CAP_PROP_POS_MSEC,t*1000); ok,frame=cap.read()
        if not ok: break
        name=f"{a.session}_{int(round(t*1000)):010d}.jpg"
        if not cv2.imwrite(str(a.output/name),frame): cap.release(); print("Frame write failed"); return 2
        manifest["frames"].append({"file":name,"timestamp_seconds":round(t,3)}); saved+=1; t+=a.interval
    cap.release()
    (a.output/"extraction_manifest.json").write_text(json.dumps(manifest,indent=2)+"\n",encoding="utf-8")
    print(f"Extracted {saved} frames. Keep this entire recording session in one split.")
    return 0 if saved else 1
if __name__=="__main__": raise SystemExit(main())
