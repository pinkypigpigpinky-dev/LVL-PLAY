"""Standard-library smoke tests for the dataset validator."""
import json, subprocess, sys, tempfile, unittest
from pathlib import Path
SCRIPT=Path(__file__).with_name("validate_dataset.py")
class ValidatorTests(unittest.TestCase):
    def make_dataset(self,root):
        manifest={"dataset_name":"test","rights_owner":"owner","permission_basis":"permission","license":"test-only","source_notes":"synthetic fixture","classes":[{"name":"player"}]}
        (root/"dataset_manifest.json").write_text(json.dumps(manifest))
        for split in ("train","val","test"):
            (root/"images"/split).mkdir(parents=True); (root/"labels"/split).mkdir(parents=True)
            (root/"images"/split/"sample.jpg").write_bytes(("image-"+split).encode())
            (root/"labels"/split/"sample.txt").write_text("0 0.5 0.5 0.2 0.2\n")
    def test_valid_structure(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); self.make_dataset(root)
            run=subprocess.run([sys.executable,str(SCRIPT),str(root)],capture_output=True,text=True)
            self.assertEqual(run.returncode,0,run.stdout+run.stderr)
            self.assertIn("RESULT: PASS",run.stdout)
    def test_rejects_out_of_range_box(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); self.make_dataset(root)
            (root/"labels/train/sample.txt").write_text("0 1.5 0.5 0.2 0.2\n")
            run=subprocess.run([sys.executable,str(SCRIPT),str(root)],capture_output=True,text=True)
            self.assertEqual(run.returncode,1)
            self.assertIn("coordinates must be normalized",run.stdout)
if __name__=="__main__": unittest.main()
