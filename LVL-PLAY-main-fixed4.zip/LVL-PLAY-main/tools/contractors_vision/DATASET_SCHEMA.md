# Contractors visual dataset protocol

This directory defines a data contract and local tooling; it does not contain gameplay captures or trained weights.

## Rights and privacy gate

Use only footage the contributor is legally allowed to use for model training and redistribution under the intended project license. Record rights owner, permission basis, license, capture source, and restrictions in dataset_manifest.json. Owning a game copy does not automatically grant redistribution rights to footage or extracted assets. Do not scrape private streams. Remove or obscure player names, account IDs, voice chat, and other personal information. A manifest is a provenance record, not proof of legal rights; maintainers must review it.

## TF2 transfer-learning candidate

The Roboflow Universe page for "Team Fortress 2 Classes" v5 lists 2,215 images and labels the dataset Public Domain. This is a lead for a controlled transfer-learning experiment, not automatic clearance: the page's license label does not establish rights to the underlying Valve game imagery. Verify creator terms and upstream rights before use. It is an image dataset, not raw gameplay video. TF2's stylized visuals are not a substitute for Contractors footage or a Contractors validation set. Keep TF2 experiments separate and label their metrics as TF2-only. See the [dataset listing](https://universe.roboflow.com/vinicius-soares/team-fortress-2-classes/dataset/5).

## Initial generic visual classes

IDs follow manifest order: player_character, weapon, projectile, objective_marker, hud_marker. These are visible-object labels only, not hostility, team, intent, or threat. Do not add enemy/ally labels without a visually reliable distinction and separate evaluation. Never infer hostility from position or movement.

## Dataset layout

    dataset/
      dataset_manifest.json
      images/{train,val,test}/
      labels/{train,val,test}/

YOLO label lines use class_id x_center y_center width height with normalized values from 0 to 1. Empty label files represent reviewed negative images. Keep matching relative paths and .txt extensions. Split by complete recording session; near-duplicate frames from one video must not cross splits.

## Manifest

Copy and complete this structure with real values:

    {
      "dataset_name": "LVL PLAY Contractors Visual Dataset",
      "rights_owner": "REPLACE",
      "permission_basis": "REPLACE",
      "license": "REPLACE",
      "source_notes": "Capture device, game build, maps, dates and restrictions",
      "classes": [{"name":"player_character"},{"name":"weapon"},{"name":"projectile"},{"name":"objective_marker"},{"name":"hud_marker"}],
      "splits": {"train":"session IDs","val":"session IDs","test":"session IDs"}
    }

## Local workflow and release gate

See README.md. extract_frames.py samples local video; annotate_yolo.py creates YOLO labels with a local OpenCV GUI; import_yolo_dataset.py imports an already-downloaded YOLO dataset with an explicit class map; validate_dataset.py checks structure and labels; train_yolo.py trains from an already-local checkpoint; evaluate_yolo.py evaluates the held-out test split. No script uploads data or automatically downloads weights.

Training provenance includes checkpoint and dataset manifest hashes. A TFLite export is only a candidate: Android Task Vision requires compatible metadata and output tensors. Verify the exported artifact and load it in the app before integration. Evaluate per-class precision/recall/AP, confusion matrix, false positives per minute, and misses across game conditions. Quest acceptance additionally requires sustained physical-headset latency, memory, and thermal tests.

No unresolved rights restrictions; no session leakage; reviewed positive and negative examples; untouched test metrics; long negative clips; app Task Vision load; and sustained Quest hardware tests. No claim of enemy recognition or tactical reliability without separate evidence.
