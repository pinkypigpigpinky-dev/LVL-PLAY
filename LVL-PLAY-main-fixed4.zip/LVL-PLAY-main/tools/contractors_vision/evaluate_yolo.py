#!/usr/bin/env python3
"""Evaluate a local checkpoint against the held-out test split."""
import argparse, json
from pathlib import Path
def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument("dataset",type=Path); p.add_argument("checkpoint",type=Path)
    p.add_argument("--imgsz",type=int,default=640); p.add_argument("--output",type=Path,default=Path("runs/contractors/test_metrics.json"))
    a=p.parse_args()
    if not a.checkpoint.is_file(): print("Checkpoint not found"); return 2
    if not (a.dataset/"images/test").is_dir(): print("Missing held-out images/test split"); return 2
    try:
        import yaml
        from ultralytics import YOLO
    except ImportError: print("Install local training requirements"); return 2
    manifest=json.loads((a.dataset/"dataset_manifest.json").read_text(encoding="utf-8"))
    names=[x["name"] if isinstance(x,dict) else x for x in manifest["classes"]]
    config={"path":str(a.dataset.resolve()),"train":"images/train","val":"images/val","test":"images/test","names":names}
    a.output.parent.mkdir(parents=True,exist_ok=True); yml=a.output.with_suffix(".yaml")
    yml.write_text(yaml.safe_dump(config,sort_keys=False),encoding="utf-8")
    metrics=YOLO(str(a.checkpoint)).val(data=str(yml),split="test",imgsz=a.imgsz,plots=True)
    result={"checkpoint":str(a.checkpoint),"split":"test","metrics":metrics.results_dict,
      "per_class_map50":getattr(metrics.box,"maps",[]).tolist() if hasattr(metrics.box,"maps") else []}
    a.output.write_text(json.dumps(result,indent=2,default=str)+"\n",encoding="utf-8")
    print(json.dumps(result,indent=2,default=str)); return 0
if __name__=="__main__": raise SystemExit(main())
