#!/usr/bin/env python3
"""Import an already-downloaded YOLO dataset into LVL PLAY's canonical layout.

No downloader is included: supply a dataset you are authorized to use. A class
mapping JSON maps source class names to target class names, or null to discard.
"""
import argparse, json, shutil
from pathlib import Path

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("source",type=Path,help="Extracted YOLO dataset root containing data.yaml")
    p.add_argument("destination",type=Path)
    p.add_argument("--mapping",type=Path,required=True,help='JSON object, e.g. {"Scout":"player_character","Rocket":"projectile"}')
    p.add_argument("--dataset-name",required=True); p.add_argument("--rights-owner",required=True)
    p.add_argument("--permission-basis",required=True); p.add_argument("--license",required=True)
    p.add_argument("--source-notes",required=True)
    a=p.parse_args()
    try: import yaml
    except ImportError: print("Install PyYAML from requirements-training.txt"); return 2
    config_path=a.source/"data.yaml"
    if not config_path.is_file(): print("Source data.yaml not found"); return 2
    config=yaml.safe_load(config_path.read_text(encoding="utf-8"))
    names=config.get("names",[])
    if isinstance(names,dict): names=[names[k] for k in sorted(names,key=lambda x:int(x))]
    if not names: print("No class names found in data.yaml"); return 2
    mapping=json.loads(a.mapping.read_text(encoding="utf-8"))
    missing=[str(n) for n in names if str(n) not in mapping]\n    if missing: print("Missing explicit mapping for source classes:", ", ".join(missing)); return 2\n    targets=sorted({v for v in mapping.values() if v is not None})
    if not targets: print("Mapping must retain at least one class"); return 2
    if a.destination.exists() and any(a.destination.iterdir()): print("Destination must be empty or absent"); return 2
    root=a.destination; root.mkdir(parents=True,exist_ok=True)
    manifest={"dataset_name":a.dataset_name,"rights_owner":a.rights_owner,"permission_basis":a.permission_basis,
      "license":a.license,"source_notes":a.source_notes,"source_game":"Team Fortress 2 (transfer-learning source; not Contractors data)",
      "classes":[{"name":n} for n in targets],"source_class_mapping":mapping}
    (root/"dataset_manifest.json").write_text(json.dumps(manifest,indent=2)+"\n",encoding="utf-8")
    split_alias={"train":"train","val":"val","valid":"val","test":"test"}
    for source_split,target_split in split_alias.items():
        image_dir=a.source/"images"/source_split; label_dir=a.source/"labels"/source_split
        if not image_dir.is_dir(): continue
        out_img=root/"images"/target_split; out_lab=root/"labels"/target_split
        out_img.mkdir(parents=True,exist_ok=True); out_lab.mkdir(parents=True,exist_ok=True)
        for img in image_dir.rglob("*"):
            if not img.is_file(): continue
            rel=img.relative_to(image_dir); shutil.copy2(img,out_img/rel)
            src_label=label_dir/rel.with_suffix(".txt")
            if not src_label.is_file(): print("Missing label:",src_label); return 1
            rows=[]
            for line_no,line in enumerate(src_label.read_text(encoding="utf-8").splitlines(),1):
                fields=line.split()
                if len(fields)!=5: print(f"Malformed label {src_label}:{line_no}"); return 1
                try: idx=int(fields[0])
                except ValueError: print(f"Bad class ID {src_label}:{line_no}"); return 1
                if idx<0 or idx>=len(names): print(f"Class ID outside source names: {src_label}:{line_no}"); return 1
                source_name=str(names[idx]); target=mapping.get(source_name)
                if target is None: continue
                if target not in targets: print("Invalid target mapping:",target); return 1
                rows.append(str(targets.index(target))+" "+" ".join(fields[1:]))
            (out_lab/rel.with_suffix(".txt")).write_text("\n".join(rows)+("\n" if rows else ""),encoding="utf-8")
    print("Imported files. IMPORTANT: confirm rights and review class mapping before training.")
    print("Run validate_dataset.py, then independently inspect representative annotations.")
    return 0
if __name__=="__main__": raise SystemExit(main())
