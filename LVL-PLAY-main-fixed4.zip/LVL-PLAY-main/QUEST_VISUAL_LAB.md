# Quest Visual Lab — local visual-analysis subsystem

## Purpose

Quest Visual Lab is a separate Quest-first visual-analysis component in LIV PLAY. It is independent of LIV's voice coach and the Windows/SteamVR PCVR experiment. The system processes user-selected footage locally; it does not require a Contractors mod for offline clip analysis.

## 0.5.0 development implementation

### Local object detection

- Integrates TensorFlow Lite Task Vision's on-device ObjectDetector API.
- The user imports a local `.tflite` model through Android's document picker.
- The model is copied to app-private storage and validated by attempting to initialize the Task Vision detector.
- Screenshot and sampled video frames are passed to the local detector.
- Model labels, confidence scores, and bounding boxes are returned by the inference runtime.
- Model weights are deliberately not bundled yet: users must supply a compatible, properly licensed model with the metadata required by Task Vision.
- A generic COCO model can detect common classes such as people, but it is not trained to identify Contractors classes, weapons, enemy teams, or hostile intent.

TensorFlow's Task Vision object detector expects compatible TFLite object-detection models with metadata. See the [Android object-detection guide](https://developers.google.com/codelabs/tflite-object-detection-android) and [Task Library model requirements](https://android.googlesource.com/platform/external/tensorflow/+/HEAD/tensorflow/lite/g3doc/inference_with_metadata/task_library/object_detector.md).

### Multi-frame tracking

- A greedy IoU tracker associates same-label boxes between sampled frames.
- Track IDs are stable across adjacent samples when the overlap gate is met.
- Tracks retain consecutive-hit counts and expire after missed frames.
- Single-frame screenshot detections are explicitly provisional; the system does not claim temporal confirmation for them.

### Camera-motion compensation

- A coarse global translation estimate is computed from downsampled luminance frames using block matching.
- The translation estimate shifts prior track boxes before association.
- A quality/separation score is returned with each estimate.
- This is a 2D translation approximation only. It is not full optical flow, image stabilization, SLAM, or Quest headset pose tracking. Rotation, zoom, parallax, and large scene changes can defeat it.

### Tactical scene interpretation

- The interpreter groups model labels into broad person-like, weapon-like, and other categories only when those labels are actually emitted by the selected model.
- A detection must persist across multiple sampled frames before being included in the stable-object assessment.
- The assessment includes model confidence and an explicit caution.
- Person-like does not mean enemy; weapon-like does not prove a weapon is held or hostile.
- No enemy team, intent, health, class, or threat level is inferred from generic labels.

### Local visual memory and LIV connection

- A bounded history of recent observation summaries is stored in app-private SharedPreferences.
- LIV's tactical coach also stores the latest visual summary in its local tactical preferences.
- Ask LIV **"What did you see?"** after analyzing footage to retrieve the last summary.
- Say **"Clear visual memory"** to clear the coach's latest saved summary. Say **Clear visual memory** to clear both the bounded history and LIV's latest-summary bridge.
- Raw video frames are not saved by the visual-memory component.

## How to use and test

1. Build and install LIV PLAY on the Quest.
2. Open **Quest Visual Lab** from the launcher.
3. Choose **Load .tflite model** and select a compatible TensorFlow Lite Task Vision object detector. The model must include valid Task Library metadata and labels.
4. If model validation succeeds, choose a screenshot or a short gameplay video.
5. For video, up to ten timestamps are sampled. Each decoded frame is scaled to a maximum 640-pixel long edge before analysis.
6. Review labels, confidence values, track IDs, and frame counts. A one-frame screenshot result is provisional.
7. Compare the same clip with and without camera movement. The camera-shift estimate is only a coarse translation.
8. In LIV's voice coach, ask **"What did you see?"** to retrieve the last saved scene summary.
9. Turn off network access during the test. The detector and visual-memory code do not call a hosted inference service.

## Model requirements and licensing

No object-detection model weights are included in the repository. The model picker accepts a user-supplied local model. Use a Task Vision-compatible object detector with embedded metadata and labels. Check the model's license and provenance before importing it. A model trained on ordinary photographs is unlikely to perform reliably on stylized, fast-moving Contractors footage. A dedicated Contractors model requires permission-cleared gameplay frames, labeled bounding boxes, representative class balance, evaluation, and a documented license.

## Platform boundary and cross-app capture

This subsystem analyzes files the user explicitly selects. It does not automatically capture Contractors while Contractors is running as another standalone Quest app, inspect its private framebuffer, or draw markers over its immersive session.

**Do not implement tactical inference from Quest MediaProjection.** Meta's Horizon OS MediaProjection policy limits that API to user-consented casting, live streaming, and screen sharing; it is not an approved source for game-state/tactical analysis. The permission dialog alone does not make a different use permissible. See the [Meta MediaProjection API and policy](https://developers.meta.com/vr/documentation/native/native-media-projection/).

A normal third-party Quest app also cannot attach its own OpenXR composition layer to another app's immersive session. The existing OpenXR HUD is rendered only inside LIV PLAY's own OpenXR session. It must not be described as a Contractors overlay.

Supported paths:
- Analyze user-selected screenshots and recordings locally.
- Render visual indicators and HUD elements inside LIV PLAY's own OpenXR session.
- Use a documented, explicitly permitted game-provided event or image integration if one becomes available.
- Keep cross-app casting/screen-sharing as a separate user-facing feature only if it is implemented for Meta-approved sharing purposes; do not route that stream into the tactical detector.

Do not use hidden compositor access, private APIs, process injection, game-memory reading, or anti-cheat bypass.

## Current limitations

- No model weights are bundled.
- Semantic quality depends entirely on the imported model; the app cannot make an unsuitable model understand game-specific objects.
- Tracking and camera compensation are lightweight prototypes, not production-grade multi-object tracking or 6DoF stabilization.
- No live Quest capture, real-time in-game overlay, or Contractors integration is present.
- No APK build or physical Quest benchmark has been confirmed for this milestone.

## Next stages

### 0.6 — Game-specific perception
- Curate a permission-cleared Contractors dataset.
- Train/evaluate a local detector for visible player silhouettes, weapons, projectiles, and relevant HUD elements.
- Calibrate per-class confidence and false-positive rates.
- Improve tracking with appearance embeddings and camera-motion estimation.
- Profile CPU/GPU delegates, memory, thermal behavior, and battery on Quest 2/3/3S.
- Add an explicit model details page with version, labels, license, and checksum.

### 0.7 — Tactical reasoning
- Add map/objective context and player-confirmed loadout.
- Add temporal event summaries and uncertainty-aware coaching.
- Add duplicate suppression and user-controlled voice callouts.
- Keep all inference and memory local.

### 0.8 — Approved live source
- Connect only to a documented and permitted live image/event source.
- Make source state, freshness, and dropped frames visible.
- Fall back to imported footage or player-described context when live input is unavailable.

## Current status

**0.5.0 source milestone:** local model loading, TFLite Task Vision inference, multi-frame box association, coarse 2D camera-shift compensation, confidence-aware scene summaries, bounded local visual history, and the latest-summary bridge into LIV's coach have been added in source. Model weights are not bundled. APK build, inference on Quest hardware, thermal performance, and gameplay accuracy remain unverified.

## 0.6 dataset and model pipeline foundation

The repository now includes a rights-first dataset contract under `tools/contractors_vision/`:

- `DATASET_SCHEMA.md` defines proposed visible-object classes, annotation rules, privacy restrictions, session-level train/validation/test splitting, evaluation metrics, TFLite export requirements, and Quest acceptance gates.
- `dataset_manifest.template.json` records the rights holder, permission basis, license, source notes, class order, and recording/session split provenance. Placeholder rights fields must be replaced and reviewed before training.
- `validate_dataset.py` checks the YOLO-format directory structure, manifest fields, paired image/label files, normalized coordinates, class IDs, orphan labels, and exact duplicate image bytes across splits. It uses only the Python standard library.

Run it with:

```bash
python tools/contractors_vision/validate_dataset.py /path/to/dataset
```

This is the pipeline foundation, not a trained model. No footage or weights have been added. The validator cannot establish that permissions are genuine, annotations are correct, near-duplicate clips are separated, or a model is accurate. Model training and Quest performance benchmarking remain blocked on permission-cleared representative footage, annotation review, a compatible export, and physical Quest access.

Proposed initial classes are visible player characters, weapons, projectiles, objective markers, and other HUD markers. They deliberately do not encode enemy/ally status or hostile intent.


## 0.6 dual-model routing milestone

Quest Visual Lab now supports two independent local model slots:

- **General detector:** broad object coverage and fallback detections.
- **Game-specific detector:** optional model trained for the target game's visual domain.
- Both detectors process the same sampled frame locally. When a game-specific box overlaps a general box at or above the configured IoU threshold (default 0.55), the game-specific result takes precedence. Non-overlapping general results remain as fallbacks.
- Every returned detection carries a `general` or `game-specific` source tag. Track association keeps model sources separate, preventing a general-model box from silently continuing a game-specific track.
- If only one model is loaded, the router uses that model alone. This preserves the previous single-model workflow.

This arbitration is intentionally simple and deterministic. It does not average confidence scores, merge labels, establish that the game-specific model is more accurate, or infer teams/hostility. Validate both models on the same held-out Contractors clips before trusting the priority rule. Running two models also increases inference time and thermal load; Quest profiling is still required.

Models are stored separately in app-private storage as `general-detector.tflite` and `game-detector.tflite`. Existing installations using the earlier `model_path` preference retain it as the general-model fallback.
