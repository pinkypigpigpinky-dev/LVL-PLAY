# Build the LIV PLAY Quest APK on Windows

This path does **not** use GitHub Actions, Render, Android Studio, or a hosted build service. GitHub remains the source-code home; the APK is compiled on your Windows PC.

## One-time setup

1. Download or clone this repository to Windows.
2. Install Windows App Installer if the winget command is missing.
3. Double-click Build-LIV-Quest.bat.

The script installs or prepares, and verifies the Android command-line tools download using Google’s published SHA-256 checksum:
- Eclipse Temurin JDK 17
- Gradle 8.11.1
- Android SDK command-line tools
- Android platform 35 and Build Tools 35.0.0
- CMake 3.22.1 and Android NDK 27.2.12479018

It accepts the Android SDK licences, writes local.properties for this checkout, and runs :app:assembleDebug.

## Output

A successful build creates:

dist\LIV-PLAY-Quest-debug.apk

This is a debug/test APK, not a Play Store release or a verified production-signed build. Install it on the Quest with Meta Quest Developer Hub or Android Debug Bridge after enabling developer mode.

## Troubleshooting

- If JDK installation completes but Java is not detected, close the window, reopen it, and run the batch file again.
- Keep an internet connection available: Gradle, Android SDK packages, the Sherpa ONNX AAR, and the Piper voice model are downloaded during setup/build.
- The first build can take a while and needs several gigabytes of free disk space.
- If Gradle fails, copy the first error and the final build output when asking for help. Do not delete the project or SDK folders before diagnosing it.
- The build script deliberately stops on errors and does not claim an APK exists unless it finds the output file.

## Current feature limitations

A successful APK build does not prove the Quest cross-app HUD works over Contractors. The current HUD panel is a coexistence prototype, not a passive transparent overlay, and it has no live Contractors enemy feed. Those capabilities still require supported platform/game integration and physical headset testing.
