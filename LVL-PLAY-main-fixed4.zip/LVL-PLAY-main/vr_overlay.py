"""LIV PLAY SteamVR HUD prototype.

Captures a selected desktop monitor locally, detects motion regions with OpenCV,
and draws a transparent HUD as an OpenVR overlay in the headset.
This is a head-locked 2D HUD, not world-locked object annotation.
"""
from __future__ import annotations
import os, sys, time, traceback, ctypes
import cv2
import numpy as np
import mss
import openvr
from PIL import Image, ImageDraw, ImageFont

W, H = 1280, 720
FPS = max(5, min(30, int(os.getenv("LIV_PLAY_FPS", "15"))))
MONITOR = int(os.getenv("LIV_PLAY_MONITOR", "1"))
WIDTH_METERS = float(os.getenv("LIV_PLAY_HUD_WIDTH", "2.25"))
DISTANCE = float(os.getenv("LIV_PLAY_HUD_DISTANCE", "1.35"))
ALPHA = float(os.getenv("LIV_PLAY_HUD_ALPHA", "0.92"))

def font(size):
    for path in ("C:/Windows/Fonts/segoeui.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"):
        try: return ImageFont.truetype(path, size)
        except OSError: pass
    return ImageFont.load_default()

def draw_hud(tracks, source_size, fps, mode):
    img = Image.new("RGBA", (W,H), (0,0,0,0))
    d = ImageDraw.Draw(img)
    sw, sh = source_size
    # HUD coordinates map to normalized monitor coordinates. A centered game mirror
    # or fullscreen game mirror gives the best visual correspondence.
    scale = min(W/sw, H/sh)
    dw, dh = sw*scale, sh*scale
    ox, oy = (W-dw)/2, (H-dh)/2
    for t in tracks:
        x, y = ox+t["cx"]*scale, oy+t["cy"]*scale
        bw, bh = t["w"]*scale, t["h"]*scale
        color = (80,235,224,240)
        d.rounded_rectangle((x-bw/2,y-bh/2,x+bw/2,y+bh/2), radius=5, outline=color, width=3)
        d.text((x-bw/2, max(oy,y-bh/2-23)), f'MOTION #{t["id"]}', font=font(17), fill=color,
               stroke_width=2, stroke_fill=(0,0,0,190))
        lx, ly = ox+t["lead_x"]*scale, oy+t["lead_y"]*scale
        d.line((x,y,lx,ly), fill=(255,190,88,225), width=2)
        d.ellipse((lx-7,ly-7,lx+7,ly+7), outline=(255,190,88,245), width=3)
    # Compact transparent telemetry strip; not an opaque panel over the game.
    d.rounded_rectangle((22,22,390,86), radius=12, fill=(5,12,22,175), outline=(65,130,145,210), width=2)
    d.text((40,31), "LIV PLAY  /  LOCAL VISION", font=font(19), fill=(98,230,224,255))
    d.text((40,57), f"{len(tracks)} motion tracks  ·  {fps:.0f} FPS  ·  {mode}", font=font(14), fill=(225,235,247,240))
    # OpenVR raw textures expect BGRA on common Windows paths; use RGBA byte buffer.
    return np.asarray(img, dtype=np.uint8)

def main():
    print("LIV PLAY VR HUD starting. Ensure SteamVR is running and Contractors is visible on a monitor mirror.")
    if MONITOR < 1:
        raise ValueError("LIV_PLAY_MONITOR must be 1 or greater (1 is the primary monitor).")
    cv2.setNumThreads(2)
    bg = cv2.createBackgroundSubtractorMOG2(history=160, varThreshold=30, detectShadows=False)
    tracks, next_id = {}, 1
    last = time.time()
    count = 0
    try:
        openvr.init(openvr.VRApplication_Overlay)
        vr_overlay = openvr.IVROverlay()
        handle = vr_overlay.createOverlay("lvl.play.tactical.hud", "LVL PLAY Tactical HUD")
        vr_overlay.setOverlayWidthInMeters(handle, WIDTH_METERS)
        vr_overlay.setOverlayAlpha(handle, ALPHA)
        vr_overlay.setOverlayInputMethod(handle, openvr.VROverlayInputMethod_None)
        vr_overlay.setOverlayFlag(handle, openvr.VROverlayFlags_VisibleInDashboard, True)
        transform = openvr.HmdMatrix34_t()
        for r in range(3):
            for c in range(4): transform[r][c] = 0.0
        transform[0][0] = 1.0; transform[1][1] = 1.0; transform[2][2] = 1.0
        transform[2][3] = -DISTANCE
        vr_overlay.setOverlayTransformTrackedDeviceRelative(handle, openvr.k_unTrackedDeviceIndex_Hmd, transform)
        vr_overlay.showOverlay(handle)
        print("HUD visible in SteamVR. Ctrl+C to stop.")
        with mss.mss() as sct:
            if MONITOR >= len(sct.monitors):
                raise ValueError(f"Monitor {MONITOR} not found. Available monitors: {len(sct.monitors)-1}")
            monitor = sct.monitors[MONITOR]
            while True:
                start = time.time()
                shot = np.asarray(sct.grab(monitor))
                frame = cv2.cvtColor(shot, cv2.COLOR_BGRA2BGR)
                h,w = frame.shape[:2]
                factor = min(1.0, 960/w)
                small = cv2.resize(frame, (int(w*factor), int(h*factor))) if factor < 1 else frame
                mask = bg.apply(small)
                mask = cv2.medianBlur(mask,5)
                kernel = np.ones((5,5),np.uint8)
                mask = cv2.morphologyEx(mask,cv2.MORPH_OPEN,kernel)
                mask = cv2.dilate(mask,kernel,iterations=2)
                contours,_ = cv2.findContours(mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
                detections=[]
                for contour in contours:
                    area=cv2.contourArea(contour)
                    if area < 350 or area > 180000: continue
                    x,y,bw,bh=cv2.boundingRect(contour)
                    inv=1/factor
                    detections.append(( (x+bw/2)*inv,(y+bh/2)*inv,bw*inv,bh*inv ))
                now=time.time(); dt=max(.03,min(.5,now-last)); last=now
                unmatched=set(tracks)
                current=[]
                for cx,cy,bw,bh in detections:
                    best=None; dist=1e9
                    for tid in list(unmatched):
                        tr=tracks[tid]; dd=float(np.hypot(cx-tr["cx"],cy-tr["cy"]))
                        if dd<max(55,.8*max(bw,bh,tr["w"],tr["h"])) and dd<dist: best,dist=tid,dd
                    if best is None:
                        tid=next_id; next_id+=1
                        tracks[tid]={"cx":cx,"cy":cy,"w":bw,"h":bh,"vx":0.,"vy":0.,"seen":now}
                    else:
                        tid=best; unmatched.discard(tid); tr=tracks[tid]
                        vx=(cx-tr["cx"])/dt; vy=(cy-tr["cy"])/dt
                        tr.update(cx=cx,cy=cy,w=bw,h=bh,vx=.55*vx+.45*tr["vx"],vy=.55*vy+.45*tr["vy"],seen=now)
                    tr=tracks[tid]
                    current.append({"id":tid,**tr,"lead_x":float(np.clip(tr["cx"]+tr["vx"]*.28,0,w)),
                                    "lead_y":float(np.clip(tr["cy"]+tr["vy"]*.28,0,h))})
                for tid in unmatched:
                    if now-tracks[tid]["seen"]>.65: del tracks[tid]
                count+=1
                elapsed=time.time()-start
                actual_fps=1/max(.001,elapsed)
                rgba=draw_hud(current,(w,h),actual_fps,"MOTION")
                # Keep a strong reference to the bytes until SetOverlayRaw returns.
                raw=ctypes.create_string_buffer(rgba.tobytes())
                vr_overlay.setOverlayRaw(handle,raw,W,H,4)
                delay=max(0,1/FPS-(time.time()-start))
                time.sleep(delay)
    except KeyboardInterrupt:
        print("\nStopping LIV PLAY HUD.")
    finally:
        try:
            if 'handle' in locals(): vr_overlay.hideOverlay(handle); vr_overlay.destroyOverlay(handle)
        except Exception: pass
        try: openvr.shutdown()
        except Exception: pass

if __name__ == "__main__":
    try: main()
    except Exception as exc:
        print("\nLIV PLAY VR HUD could not start:",exc)
        traceback.print_exc()
        input("\nPress Enter to close...")
