import java.net.URL
import java.security.MessageDigest

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.lvl.play"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.lvl.play"
        minSdk = 32
        targetSdk = 34
        versionCode = 6
        versionName = "0.8.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        ndk {
            abiFilters += listOf("arm64-v8a")
        }
        externalNativeBuild {
            cmake {
                cppFlags += listOf("-std=c++17", "-Wall", "-Wextra")
            }
        }
    }

    buildFeatures {
        prefab = true
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    testOptions {
        unitTests.isReturnDefaultValues = true
    }
}

val prepareLivVoiceAssets by tasks.registering {
    val aarFile = layout.projectDirectory.file("libs/sherpa-onnx-2.0.1.aar").asFile
    val modelDir = layout.projectDirectory.dir("src/main/assets/liv_voice").asFile
    val aarUrl = "https://github.com/k2-fsa/sherpa-onnx/releases/download/v2.0.1/sherpa-onnx-2.0.1.aar"
    val modelUrl = "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-en_GB-alba-medium-int8.tar.bz2"
    val aarSha256 = "a8d09d1d32f3eb852048c2d3d43fae674681c5b050385967c70a3c2c9bf0ee7"
    val modelSha256 = "f7581d123ae977f64f3032bb247d4deeac8440e881d918d36fdd36d8f1030fb7"

    fun sha256(file: java.io.File): String =
        MessageDigest.getInstance("SHA-256").digest(file.readBytes())
            .joinToString("") { "%02x".format(it) }

    fun downloadVerified(url: String, destination: java.io.File, expectedSha: String) {
        destination.parentFile.mkdirs()
        if (destination.isFile && sha256(destination) == expectedSha) return
        val temporary = java.io.File(destination.parentFile, destination.name + ".download")
        URL(url).openStream().use { input ->
            temporary.outputStream().use { output -> input.copyTo(output) }
        }
        check(sha256(temporary) == expectedSha) { "SHA-256 verification failed for $url" }
        check(temporary.renameTo(destination)) { "Could not install downloaded file: $destination" }
    }

    doLast {
        downloadVerified(aarUrl, aarFile, aarSha256)
        val archive = layout.buildDirectory.file("voice/vits-piper-en_GB-alba-medium-int8.tar.bz2").get().asFile
        downloadVerified(modelUrl, archive, modelSha256)

        val existingModel = modelDir.resolve("en_GB-alba-medium-int8.onnx")
        val voiceAssetsComplete = existingModel.isFile &&
            modelDir.resolve("tokens.txt").isFile &&
            modelDir.resolve("espeak-ng-data").isDirectory
        if (!voiceAssetsComplete) {
            val extractionRoot = layout.buildDirectory.dir("voice/extracted").get().asFile
            extractionRoot.deleteRecursively()
            extractionRoot.mkdirs()
            val process = ProcessBuilder(
                "tar", "-xjf", archive.absolutePath, "-C", extractionRoot.absolutePath
            ).redirectErrorStream(true).start()
            val output = process.inputStream.bufferedReader().readText()
            check(process.waitFor() == 0) { "Could not extract LIV voice model: $output" }
            val extractedModel = extractionRoot.walkTopDown()
                .firstOrNull { it.isFile && it.name == "en_GB-alba-medium-int8.onnx" }
                ?: error("Voice archive did not contain the expected Alba int8 ONNX model")
            val extractedRoot = extractedModel.parentFile
            modelDir.deleteRecursively()
            modelDir.mkdirs()
            extractedRoot.copyRecursively(modelDir, overwrite = true)
        }
        check(modelDir.resolve("tokens.txt").isFile) { "LIV voice tokens.txt is missing" }
        check(modelDir.resolve("espeak-ng-data").isDirectory) { "LIV voice espeak-ng-data is missing" }
    }
}

tasks.named("preBuild").configure {
    dependsOn(prepareLivVoiceAssets)
}

dependencies {
    implementation("org.khronos.openxr:openxr_loader_for_android:1.1.49")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation(platform("androidx.compose:compose-bom:2025.02.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    // Bundled offline Piper Alba British female voice runtime (arm64 Quest target).
    implementation(files("libs/sherpa-onnx-2.0.1.aar"))
    // Fully on-device TensorFlow Lite Task Vision; model weights are user-supplied local files.
    implementation("org.tensorflow:tensorflow-lite-task-vision:0.4.4")
    debugImplementation("androidx.compose.ui:ui-tooling")
    testImplementation("junit:junit:4.13.2")
}
