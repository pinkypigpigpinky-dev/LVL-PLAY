package com.lvl.play.vision

import android.graphics.Bitmap
import android.graphics.RectF
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class CameraShift(val dx: Float, val dy: Float, val confidence: Float)

data class TrackedObject(
    val id: Int,
    val label: String,
    val confidence: Float,
    val bounds: RectF,
    val consecutiveFrames: Int,
    val modelSource: String = "general"
)

/**
 * Estimates coarse global camera translation by block-matching downsampled
 * luminance frames. This is a translation-only approximation, not full 6DoF
 * headset pose estimation or robust optical flow.
 */
class CameraMotionEstimator(
    private val sampleWidth: Int = 48,
    private val sampleHeight: Int = 27,
    private val searchRadius: Int = 5
) {
    fun estimate(previous: Bitmap, current: Bitmap): CameraShift {
        if (previous.width != current.width || previous.height != current.height) {
            return CameraShift(0f, 0f, 0f)
        }
        val a = sample(previous)
        val b = sample(current)
        var bestCost = Double.MAX_VALUE
        var secondCost = Double.MAX_VALUE
        var bestX = 0
        var bestY = 0
        for (dy in -searchRadius..searchRadius) {
            for (dx in -searchRadius..searchRadius) {
                var cost = 0.0
                var count = 0
                for (y in searchRadius until sampleHeight - searchRadius step 2) {
                    for (x in searchRadius until sampleWidth - searchRadius step 2) {
                        val oldValue = a[y * sampleWidth + x]
                        val newValue = b[(y + dy) * sampleWidth + x + dx]
                        cost += abs(oldValue - newValue)
                        count++
                    }
                }
                val mean = if (count == 0) Double.MAX_VALUE else cost / count
                if (mean < bestCost) {
                    secondCost = bestCost
                    bestCost = mean
                    bestX = dx
                    bestY = dy
                } else if (mean < secondCost) {
                    secondCost = mean
                }
            }
        }
        val separation = if (secondCost.isFinite() && secondCost > 0.0) {
            ((secondCost - bestCost) / secondCost).toFloat().coerceIn(0f, 1f)
        } else 0f
        val quality = (1f - (bestCost / 255.0).toFloat()).coerceIn(0f, 1f)
        return CameraShift(
            dx = bestX.toFloat() * previous.width / sampleWidth,
            dy = bestY.toFloat() * previous.height / sampleHeight,
            confidence = (quality * separation).coerceIn(0f, 1f)
        )
    }

    private fun sample(bitmap: Bitmap): FloatArray {
        val pixels = IntArray(sampleWidth * sampleHeight)
        val scaled = Bitmap.createScaledBitmap(bitmap, sampleWidth, sampleHeight, true)
        scaled.getPixels(pixels, 0, sampleWidth, 0, 0, sampleWidth, sampleHeight)
        if (scaled !== bitmap) scaled.recycle()
        return FloatArray(pixels.size) { index ->
            val c = pixels[index]
            0.2126f * (c shr 16 and 255) + 0.7152f * (c shr 8 and 255) + 0.0722f * (c and 255)
        }
    }
}

/**
 * Greedy IoU association with global camera-translation compensation.
 * Tracks need multiple consecutive observations before being promoted.
 */
class ObjectTrackManager(
    private val iouThreshold: Float = 0.18f,
    private val maxMissedFrames: Int = 2
) {
    private data class Track(
        val id: Int,
        var label: String,
        var confidence: Float,
        var bounds: RectF,
        var modelSource: String,
        var hits: Int,
        var missed: Int
    )

    private val tracks = mutableListOf<Track>()
    private var nextId = 1

    fun update(detections: List<DetectedObject>, cameraShift: CameraShift): List<TrackedObject> {
        tracks.forEach { track ->
            if (cameraShift.confidence >= 0.12f) {
                track.bounds.offset(-cameraShift.dx, -cameraShift.dy)
            }
            track.missed++
        }

        val unmatched = detections.toMutableList()
        for (track in tracks) {
            val candidate = unmatched
                .filter { it.modelSource == track.modelSource && it.label.equals(track.label, ignoreCase = true) }
                .maxByOrNull { iou(track.bounds, it.bounds) }
            if (candidate != null && iou(track.bounds, candidate.bounds) >= iouThreshold) {
                track.bounds = RectF(candidate.bounds)
                track.confidence = candidate.confidence
                track.hits++
                track.missed = 0
                unmatched.remove(candidate)
            }
        }
        unmatched.forEach { detection ->
            tracks += Track(
                id = nextId++,
                label = detection.label,
                confidence = detection.confidence,
                bounds = RectF(detection.bounds),
                modelSource = detection.modelSource,
                hits = 1,
                missed = 0
            )
        }
        tracks.removeAll { it.missed > maxMissedFrames }
        return tracks.filter { it.missed == 0 }.map {
            TrackedObject(it.id, it.label, it.confidence, RectF(it.bounds), it.hits, it.modelSource)
        }
    }

    private fun iou(a: RectF, b: RectF): Float {
        val intersection = RectF(a)
        if (!intersection.intersect(b)) return 0f
        val intersectionArea = intersection.width() * intersection.height()
        val union = a.width() * a.height() + b.width() * b.height() - intersectionArea
        return if (union <= 0f) 0f else intersectionArea / union
    }
}
