package com.lvl.play.vision

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class TacticalVisualAssessment(
    val headline: String,
    val details: List<String>,
    val confidence: Float,
    val caution: String
)

class TacticalVisualInterpreter {
    fun assess(tracks: List<TrackedObject>): TacticalVisualAssessment {
        val stable = tracks.filter { it.consecutiveFrames >= 2 && it.confidence >= 0.45f }
        val personLike = stable.filter { it.label.isPersonLabel() }
        val weaponLike = stable.filter { it.label.isWeaponLabel() }
        val details = mutableListOf<String>()

        if (personLike.isNotEmpty()) {
            details += "${personLike.size} persistent person-like detection(s) in the analyzed footage."
        }
        if (weaponLike.isNotEmpty()) {
            details += "${weaponLike.size} persistent weapon-like detection(s) according to the selected model labels."
        }
        val other = stable.size - personLike.size - weaponLike.size
        if (other > 0) details += "$other other persistent object detection(s)."
        if (details.isEmpty()) details += "No object detections have persisted across enough sampled frames to report."

        val confidence = if (stable.isEmpty()) 0f else stable.map {
            it.confidence * (it.consecutiveFrames / 3f).coerceIn(0.35f, 1f)
        }.average().toFloat()
        val caution = "These are model predictions from imported footage, not verified game entities. A person-like label does not identify team or hostility. Results depend on the selected model and its training data."
        return TacticalVisualAssessment(
            headline = if (stable.isEmpty()) "No stable detections" else "${stable.size} persistent detection(s)",
            details = details,
            confidence = confidence,
            caution = caution
        )
    }

    private fun String.isPersonLabel(): Boolean {
        val value = lowercase()
        return value.contains("person") || value.contains("human") || value.contains("player")
    }

    private fun String.isWeaponLabel(): Boolean {
        val value = lowercase()
        return listOf("weapon", "gun", "rifle", "pistol", "shotgun", "sniper", "rocket", "launcher").any { value.contains(it) }
    }
}

/** Small, bounded, app-private history of model observations. */
class LocalVisualMemory(context: Context, private val maxEntries: Int = 40) {
    private val prefs = context.applicationContext.getSharedPreferences("liv_visual_memory", Context.MODE_PRIVATE)

    fun record(summary: String, confidence: Float) {
        val entries = readEntries()
        entries.put(
            JSONObject()
                .put("time", System.currentTimeMillis())
                .put("summary", summary.take(500))
                .put("confidence", confidence.coerceIn(0f, 1f).toDouble())
        )
        while (entries.length() > maxEntries) entries.remove(0)
        prefs.edit().putString("observations", entries.toString()).apply()
    }

    fun latest(): String? {
        val entries = readEntries()
        if (entries.length() == 0) return null
        val last = entries.optJSONObject(entries.length() - 1) ?: return null
        return last.optString("summary").takeIf { it.isNotBlank() }
    }

    fun recent(limit: Int = 5): List<String> {
        val entries = readEntries()
        val start = (entries.length() - limit.coerceAtLeast(1)).coerceAtLeast(0)
        return (start until entries.length()).mapNotNull { index ->
            entries.optJSONObject(index)?.optString("summary")?.takeIf { it.isNotBlank() }
        }
    }

    fun clear() {
        prefs.edit().remove("observations").apply()
    }

    private fun readEntries(): JSONArray =
        runCatching { JSONArray(prefs.getString("observations", "[]")) }.getOrDefault(JSONArray())
}
