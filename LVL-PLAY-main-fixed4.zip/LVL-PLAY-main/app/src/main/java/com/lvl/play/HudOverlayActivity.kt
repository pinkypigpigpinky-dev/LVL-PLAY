package com.lvl.play

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Quest panel entry point for Meta Horizon OS's OVERLAY_LAUNCHER flow.
 *
 * This is a real 2D panel activity that Horizon OS can launch over an immersive
 * app. It is deliberately not described as a compositor layer injected into
 * another app. Enemy markers remain unavailable until a supported game-data
 * provider supplies camera-relative detections.
 */
class HudOverlayActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                var hudEnabled by remember { mutableStateOf(true) }
                var previewEnabled by remember { mutableStateOf(false) }
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xEE06121B)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(22.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("LIV // TACTICAL HUD", fontSize = 24.sp,
                                    fontWeight = FontWeight.Bold, color = Color(0xFF73F4E5))
                                Text("QUEST OVERLAY PANEL", color = Color(0xFF9BB7C4), fontSize = 11.sp)
                            }
                            Text(if (hudEnabled) "HUD ACTIVE" else "HUD HIDDEN",
                                color = if (hudEnabled) Color(0xFF73F4E5) else Color(0xFFFFB36B),
                                fontWeight = FontWeight.Bold)
                        }

                        if (hudEnabled) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                HudInfoCard("GAME DATA", "NOT CONNECTED", Modifier.weight(1f))
                                HudInfoCard("DETECTIONS", "0 LIVE TARGETS", Modifier.weight(1f))
                                HudInfoCard("RANGE", "UNAVAILABLE", Modifier.weight(1f))
                            }
                            Box(
                                modifier = Modifier.fillMaxWidth().weight(1f)
                                    .border(1.dp, Color(0xFF1D6470), RoundedCornerShape(12.dp))
                                    .background(Color(0x550A2630), RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                if (previewEnabled) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Box(
                                            modifier = Modifier.size(width = 72.dp, height = 86.dp)
                                                .border(2.dp, Color(0xFFFF5A55), RoundedCornerShape(5.dp))
                                        )
                                        Text("DEMO ONLY · NOT A LIVE ENEMY",
                                            color = Color(0xFFFFB36B), fontSize = 11.sp)
                                    }
                                } else {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text("⌖", color = Color(0xFF73F4E5), fontSize = 42.sp)
                                        Text("AWAITING A SUPPORTED LIVE DATA SOURCE",
                                            color = Color(0xFFB8D2DC), fontWeight = FontWeight.SemiBold)
                                        Text("No enemy positions are being fabricated.",
                                            color = Color(0xFF7895A2), fontSize = 12.sp)
                                    }
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(onClick = { previewEnabled = !previewEnabled }) {
                                    Text(if (previewEnabled) "Hide demo marker" else "Preview marker style")
                                }
                                Button(onClick = { hudEnabled = false }) { Text("Hide HUD") }
                            }
                        } else {
                            Text("LIV HUD is hidden. Re-enable it below.",
                                color = Color(0xFFB8D2DC), modifier = Modifier.weight(1f))
                            Button(onClick = { hudEnabled = true }) { Text("Show HUD") }
                        }

                        Text(
                            "LIVE STATUS: Quest can launch this panel over an immersive app. " +
                                "Contractors has not provided LIV with a supported live image or enemy-coordinate feed, " +
                                "so boxes, confidence and distance are not yet available.",
                            color = Color(0xFF7895A2), fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}

@androidx.compose.runtime.Composable
private fun HudInfoCard(title: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.border(1.dp, Color(0xFF1D6470), RoundedCornerShape(8.dp))
            .background(Color(0xAA0B202A), RoundedCornerShape(8.dp)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Text(title, color = Color(0xFF73F4E5), fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Text(value, color = Color(0xFFE0EDF2), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
}
