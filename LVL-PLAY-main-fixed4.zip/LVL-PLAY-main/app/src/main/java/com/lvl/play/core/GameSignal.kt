package com.lvl.play.core

/**
 * Normalized signal emitted by a future, explicitly supported game adapter.
 * Timestamps use monotonic milliseconds from the device clock.
 */
data class GameSignal(
    val sourceId: String,
    val eventId: String,
    val observedAtElapsedMs: Long,
    val confidence: Float,
    val kind: String
)

enum class SignalDecision { ACCEPT, REJECT_UNKNOWN_SOURCE, REJECT_STALE, REJECT_LOW_CONFIDENCE, REJECT_INVALID }

/**
 * Conservative gate. This does not detect enemies; it prevents unsupported,
 * stale, malformed, or weak adapter data from becoming a coaching event.
 */
object SignalGate {
    fun evaluate(
        signal: GameSignal,
        trustedSourceIds: Set<String>,
        nowElapsedMs: Long,
        maxAgeMs: Long = 350,
        minimumConfidence: Float = 0.85f
    ): SignalDecision {
        if (signal.sourceId.isBlank() || signal.eventId.isBlank() ||
            signal.kind.isBlank() || !signal.confidence.isFinite() ||
            signal.confidence !in 0f..1f || signal.observedAtElapsedMs < 0L
        ) return SignalDecision.REJECT_INVALID

        if (signal.sourceId !in trustedSourceIds) return SignalDecision.REJECT_UNKNOWN_SOURCE
        if (nowElapsedMs < signal.observedAtElapsedMs ||
            nowElapsedMs - signal.observedAtElapsedMs > maxAgeMs
        ) return SignalDecision.REJECT_STALE
        if (signal.confidence < minimumConfidence) return SignalDecision.REJECT_LOW_CONFIDENCE
        return SignalDecision.ACCEPT
    }
}
