package com.lvl.play.contractors

import com.lvl.play.core.GameSignal
import com.lvl.play.core.SignalDecision
import com.lvl.play.core.SignalGate

/**
 * Boundary between an explicitly approved Contractors-side integration and LIV PLAY.
 * No screen scraping, process inspection, memory reading, or injection is performed here.
 */
interface ContractorsEventSource {
    val sourceId: String
    val integrationVersion: String
    fun start(onSignal: (GameSignal) -> Unit, onDisconnected: (String) -> Unit)
    fun stop()
}

data class AdapterStatus(
    val connected: Boolean,
    val sourceId: String?,
    val integrationVersion: String?,
    val lastDecision: SignalDecision?,
    val detail: String
)

class ContractorsAdapter(
    private val trustedSourceIds: Set<String>,
    private val onVerifiedSignal: (GameSignal) -> Unit,
    private val onStatus: (AdapterStatus) -> Unit
) {
    private var source: ContractorsEventSource? = null

    fun connect(candidate: ContractorsEventSource) {
        disconnect()
        if (candidate.sourceId.isBlank() || candidate.sourceId !in trustedSourceIds) {
            onStatus(AdapterStatus(false, candidate.sourceId, candidate.integrationVersion,
                SignalDecision.REJECT_UNKNOWN_SOURCE, "Integration source is not trusted."))
            return
        }
        source = candidate
        candidate.start(
            onSignal = { signal ->
                val decision = SignalGate.evaluate(
                    signal = signal,
                    trustedSourceIds = trustedSourceIds,
                    nowElapsedMs = android.os.SystemClock.elapsedRealtime()
                )
                onStatus(AdapterStatus(true, candidate.sourceId, candidate.integrationVersion,
                    decision, if (decision == SignalDecision.ACCEPT) "Verified event received."
                    else "Event rejected: $decision"))
                if (decision == SignalDecision.ACCEPT) onVerifiedSignal(signal)
            },
            onDisconnected = { reason ->
                source = null
                onStatus(AdapterStatus(false, candidate.sourceId, candidate.integrationVersion,
                    null, "Game integration disconnected: $reason"))
            }
        )
        onStatus(AdapterStatus(true, candidate.sourceId, candidate.integrationVersion,
            null, "Connected to approved event source; waiting for verified events."))
    }

    fun disconnect() {
        source?.stop()
        source = null
        onStatus(AdapterStatus(false, null, null, null,
            "No Contractors game-side integration is connected."))
    }
}
