package com.lvl.play.vision

import android.content.Context
import android.graphics.Bitmap
import android.graphics.RectF
import java.io.File
import org.tensorflow.lite.support.image.TensorImage
import org.tensorflow.lite.task.vision.detector.ObjectDetector

data class DetectedObject(
    val label: String,
    val confidence: Float,
    val bounds: RectF,
    val modelSource: String = "general"
)

class LocalObjectDetector private constructor(
    private val detector: ObjectDetector,
    val modelName: String
) : AutoCloseable {
    fun detect(bitmap: Bitmap): List<DetectedObject> {
        val tensor = TensorImage.fromBitmap(bitmap)
        return detector.detect(tensor).mapNotNull { detection ->
            val category = detection.categories.maxByOrNull { it.score } ?: return@mapNotNull null
            DetectedObject(
                label = category.label.ifBlank { "unlabeled object" },
                confidence = category.score.coerceIn(0f, 1f),
                bounds = RectF(detection.boundingBox)
            )
        }
    }

    override fun close() = detector.close()

    companion object {
        fun load(context: Context, modelFile: File): LocalObjectDetector {
            require(modelFile.exists() && modelFile.length() > 0L) { "Model file is missing or empty." }
            val options = ObjectDetector.ObjectDetectorOptions.builder()
                .setMaxResults(20)
                .setScoreThreshold(0.30f)
                .build()
            val detector = ObjectDetector.createFromFileAndOptions(context, modelFile.absolutePath, options)
            return LocalObjectDetector(detector, modelFile.name)
        }
    }
}
