package com.lvl.play

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.lvl.play.coach.TacticalCoach
import com.lvl.play.speech.LocalLivSpeech
import com.lvl.play.vision.QuestVisionActivity

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    LivPlayHome()
                }
            }
        }
    }
}

@Composable
private fun LivPlayHome() {
    val context = LocalContext.current
    val speech = remember(context) { LocalLivSpeech(context) }
    val coach = remember(context) { TacticalCoach(context) }
    var voiceStatus by remember { mutableStateOf("Voice input has not been started.") }
    var lastHeard by remember { mutableStateOf("Talk to LIV about your current situation.") }
    var livReply by remember { mutableStateOf("I'm ready. Describe what's happening and I'll help you plan your next move.") }

    fun handlePlayerText(text: String) {
        lastHeard = text
        val answer = coach.respond(text)
        livReply = answer
        voiceStatus = if (speech.speak(answer)) "LIV replied using her bundled British voice."
            else "Reply generated locally. LIV's bundled British voice is still loading or unavailable."
    }

    val microphonePermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            speech.listen(::handlePlayerText, { voiceStatus = it })
        } else {
            voiceStatus = "Microphone permission was not granted."
        }
    }
    DisposableEffect(speech) {
        onDispose { speech.close() }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 32.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("LIV PLAY", fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Text("Your AI. Your Games. Your Advantage.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text("QUEST EDITION · 0.8.0", style = MaterialTheme.typography.labelMedium)
        }

        Button(onClick = {
            context.startActivity(Intent(context, QuestVisionActivity::class.java))
        }) {
            Text("Open Quest Visual Lab — analyze footage locally")
        }
        Button(onClick = {
            context.startActivity(Intent(context, HudOverlayActivity::class.java))
        }) {
            Text("Open LIV Quest HUD panel")
        }
        Button(onClick = {
            context.startActivity(Intent(context, OpenXrActivity::class.java))
        }) {
            Text("Launch immersive OpenXR runtime")
        }
        Button(onClick = {
            val spoke = speech.speak("Hello, I'm LIV. I'm here with you. What would you like to do?")
            voiceStatus = if (spoke) "LIV is speaking with her bundled voice: " + (speech.selectedVoice() ?: "British English") + "."
            else if (!speech.isReady()) "LIV's bundled British voice is loading. Try again in a moment."
            else "LIV could not start speech playback on this device."
        }) {
            Text("Test LIV — British female voice (offline)")
        }
        Button(onClick = {
            speech.stopSpeaking()
            voiceStatus = "LIV stopped speaking."
        }) {
            Text("Stop LIV speaking")
        }
        Button(onClick = {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED) {
                speech.listen(::handlePlayerText, { voiceStatus = it })
            } else {
                microphonePermission.launch(Manifest.permission.RECORD_AUDIO)
            }
        }) {
            Text("Talk to LIV — offline speech recognition")
        }
        Text(voiceStatus, style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)

        StatusPanel("You said", "LOCAL SPEECH RECOGNITION", lastHeard)
        StatusPanel("LIV's tactical response", "ON-DEVICE RULE-BASED COACH", livReply)
        StatusPanel(
            title = "Quest Visual Lab",
            status = "LOCAL IMAGE + VIDEO ANALYSIS PROTOTYPE",
            detail = "Analyzes user-selected screenshots and videos locally. Optional imported TensorFlow Lite models provide labeled detections; the pipeline includes dual-model routing, multi-frame tracking, coarse camera-motion compensation, and cautious scene summaries. No model weights are bundled, so semantic detection requires a compatible model you provide."
        )
        StatusPanel(
            title = "Standalone Quest mode",
            status = "LOCAL COACHING · IMPORTED-FOOTAGE ANALYSIS",
            detail = "LIV's speech and tactical coach run locally. Visual analysis works on imported footage, not a live feed from Contractors. Quest does not permit repurposing MediaProjection for tactical analysis, and a third-party app cannot inject an OpenXR HUD into another app's immersive session."
        )
        StatusPanel(
            title = "PCVR visual-analysis mode",
            status = "SEPARATE DESKTOP MIRROR EXPERIMENT",
            detail = "The Windows/SteamVR prototype can analyze an authorized desktop mirror locally and show motion-region indicators. Generic motion is not enemy recognition; semantic labels require a suitable local model and validation."
        )
        StatusPanel(
            title = "Local memory and privacy",
            status = "SAVED ON THIS HEADSET",
            detail = "The tactical coach stores short loadout and strategy notes in app-private preferences. Imported footage is processed locally by the visual lab and is not uploaded."
        )

        Text("Current boundaries", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        Bullet("No live Contractors image/entity feed; the new Horizon OS overlay panel is a 2D panel, not a game-render-pass overlay")
        Bullet("No hidden game-memory access, process injection, or anti-cheat bypass")
        Bullet("No external AI or cloud speech provider")
        Bullet("Visual change is not proof of an enemy or threat")
        Bullet("The tactical coach is deterministic rules-based logic, not yet a bundled local language model")

        Spacer(Modifier.height(8.dp))
        Text(
            "Build 0.8.0 · bundled British female offline voice + local coach + dual-model visual-analysis pipeline",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun StatusPanel(title: String, status: String, detail: String) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        tonalElevation = 2.dp
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(status, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            Text(detail, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun Bullet(value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text("•", fontWeight = FontWeight.Bold)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}
