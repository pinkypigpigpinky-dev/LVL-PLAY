package com.lvl.play

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class OpenXrActivity : Activity() {
    private var started = false
    private lateinit var status: TextView

    external fun nativeStart(activity: Activity): Boolean
    external fun nativeStop()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        System.loadLibrary("livplay_openxr")
        status = TextView(this).apply {
            text = "LIV PLAY is preparing its native OpenXR runtime…"
            textSize = 18f
            setPadding(32, 32, 32, 32)
        }
        setContentView(status)
    }

    override fun onResume() {
        super.onResume()
        window.decorView.post {
            if (!started) {
                started = nativeStart(this)
                status.text = if (started) {
                    "OpenXR session initialized. Stereo swapchains and the world-locked spatial HUD scaffold are rendering.\n\nRight Touch controller A button: press it three times within 1.5 seconds to toggle the LIV HUD and its demo markers on or off. This control works only while LIV PLAY owns the focused OpenXR session. The HUD contains sample graphics, not live Contractors detections."
                } else {
                    "OpenXR could not initialize. Check that this app was launched on a supported Quest headset with Horizon OS and the OpenXR runtime available."
                }
            }
        }
    }

    override fun onPause() {
        if (started) {
            nativeStop()
            started = false
        }
        super.onPause()
    }
}
