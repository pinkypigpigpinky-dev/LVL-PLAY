package com.lvl.play.vision

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max

data class VisualRegion(
    val column: Int,
    val row: Int,
    val luminance: Float,
    val edgeStrength: Float,
    val changeScore: Float
)

data class VisualReport(
    val width: Int,
    val height: Int,
    val regions: List<VisualRegion>,
    val highContrastRegions: Int,
    val changedRegions: Int,
    val note: String
)

/**
 * Lightweight on-device visual feature extractor.
 *
 * It reports image structure and inter-frame pixel change only. It is NOT an
 * enemy detector and must not label regions as players, weapons, or threats.
 */
class VisualFrameAnalyzer(
    private val columns: Int = 8,
    private val rows: Int = 6
) {
    fun analyze(bitmap: Bitmap, previous: Bitmap? = null): VisualReport {
        val width = bitmap.width
        val height = bitmap.height
        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
        val prior = if (previous != null && previous.width == width && previous.height == height) {
            IntArray(width * height).also { previous.getPixels(it, 0, width, 0, 0, width, height) }
        } else null

        val regions = ArrayList<VisualRegion>(columns * rows)
        var highContrast = 0
        var changed = 0
        for (cellY in 0 until rows) {
            for (cellX in 0 until columns) {
                val left = cellX * width / columns
                val right = minOf(width, max(left + 1, (cellX + 1) * width / columns))
                val top = cellY * height / rows
                val bottom = minOf(height, max(top + 1, (cellY + 1) * height / rows))
                if (left >= width || top >= height) {
                    regions += VisualRegion(cellX, cellY, 0f, 0f, 0f)
                    continue
                }
                var sum = 0.0
                var edges = 0.0
                var changes = 0.0
                var samples = 0
                var edgeSamples = 0
                for (y in top until bottom step 3) {
                    for (x in left until right step 3) {
                        val index = y * width + x
                        val lum = luminance(pixels[index])
                        sum += lum
                        samples++
                        if (x + 3 < right) {
                            edges += abs(lum - luminance(pixels[y * width + x + 3]))
                            edgeSamples++
                        }
                        if (y + 3 < bottom) {
                            edges += abs(lum - luminance(pixels[(y + 3) * width + x]))
                            edgeSamples++
                        }
                        if (prior != null) {
                            changes += abs(lum - luminance(prior[index]))
                        }
                    }
                }
                val average = if (samples == 0) 0f else (sum / samples).toFloat()
                val edge = if (edgeSamples == 0) 0f else (edges / edgeSamples).toFloat()
                val change = if (prior == null || samples == 0) 0f else (changes / samples).toFloat()
                if (edge >= 22f) highContrast++
                if (change >= 18f) changed++
                regions += VisualRegion(cellX, cellY, average, edge, change)
            }
        }
        val note = when {
            prior == null -> "Single-frame structure only. Import a video clip to compare sampled frames for visible pixel changes."
            changed == 0 -> "No strong inter-frame pixel changes detected at the sampled grid resolution."
            else -> "$changed of ${columns * rows} regions show notable pixel changes between sampled frames."
        }
        return VisualReport(width, height, regions, highContrast, changed, note)
    }

    private fun luminance(color: Int): Float {
        val r = (color shr 16 and 0xff).toFloat()
        val g = (color shr 8 and 0xff).toFloat()
        val b = (color and 0xff).toFloat()
        return 0.2126f * r + 0.7152f * g + 0.0722f * b
    }
}
