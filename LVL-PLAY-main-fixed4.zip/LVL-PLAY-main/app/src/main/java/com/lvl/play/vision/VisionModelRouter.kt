package com.lvl.play.vision

import android.graphics.Bitmap
import android.graphics.RectF

/**
 * Runs independent on-device detectors against the same frame.
 *
 * The game-specific model wins when its box substantially overlaps a general
 * detector box. Non-overlapping general detections are retained as fallbacks.
 * This is deterministic box-level arbitration, not an ensemble confidence score.
 */
class VisionModelRouter(
    private val generalDetector: LocalObjectDetector?,
    private val gameSpecificDetector: LocalObjectDetector?,
    private val overrideIouThreshold: Float = 0.55f
) : AutoCloseable {
    init {
        require(generalDetector != null || gameSpecificDetector != null) {
            "At least one local vision model must be loaded."
        }
        require(overrideIouThreshold in 0f..1f) {
            "The overlap threshold must be between 0 and 1."
        }
    }

    fun detect(bitmap: Bitmap): List<DetectedObject> {
        val general = generalDetector?.detect(bitmap).orEmpty()
            .map { it.copy(modelSource = "general") }
        val specific = gameSpecificDetector?.detect(bitmap).orEmpty()
            .map { it.copy(modelSource = "game-specific") }

        if (specific.isEmpty()) return general
        if (general.isEmpty()) return specific

        val fallback = general.filter { candidate ->
            specific.none { specialist ->
                intersectionOverUnion(candidate.bounds, specialist.bounds) >= overrideIouThreshold
            }
        }
        return specific + fallback
    }

    override fun close() {
        runCatching { gameSpecificDetector?.close() }
        runCatching { generalDetector?.close() }
    }

    private fun intersectionOverUnion(a: RectF, b: RectF): Float {
        val intersection = RectF(a)
        if (!intersection.intersect(b)) return 0f
        val area = intersection.width() * intersection.height()
        val union = a.width() * a.height() + b.width() * b.height() - area
        return if (union <= 0f) 0f else area / union
    }
}
