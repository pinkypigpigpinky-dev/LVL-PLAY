package com.lvl.play.vision

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lvl.play.coach.TacticalCoach
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min

class QuestVisionActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    QuestVisionScreen(applicationContext)
                }
            }
        }
    }
}

private data class VisionUiState(
    val title: String,
    val summary: String,
    val regions: List<VisualRegion> = emptyList(),
    val mapUsesEdges: Boolean = false,
    val detections: List<TrackedObject> = emptyList(),
    val assessment: String = "",
    val confidence: Float = 0f,
    val busy: Boolean = false
)

@Composable
private fun QuestVisionScreen(context: Context) {
    val scope = rememberCoroutineScope()
    val modelPreferences = remember(context) {
        context.getSharedPreferences("liv_visual_model", Context.MODE_PRIVATE)
    }
    var generalModelPath by remember(context) {
        mutableStateOf(modelPreferences.getString("general_model_path", modelPreferences.getString("model_path", null)))
    }
    var gameModelPath by remember(context) {
        mutableStateOf(modelPreferences.getString("game_model_path", null))
    }
    var modelName by remember(context) {
        mutableStateOf(buildString {
            append("General: ")
            append(generalModelPath?.let { File(it).name } ?: "not loaded")
            append(" · Game-specific: ")
            append(gameModelPath?.let { File(it).name } ?: "not loaded")
        })
    }
    var state by remember {
        mutableStateOf(
            VisionUiState(
                "No footage analyzed",
                "Load a compatible local TensorFlow Lite object-detection model, then select a screenshot or video. All inference runs on this headset."
            )
        )
    }

    fun analyze(uri: Uri, isVideo: Boolean) {
        state = state.copy(title = "Analyzing locally…", busy = true)
        val selectedGeneral = generalModelPath?.let(::File)
        val selectedGame = gameModelPath?.let(::File)
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    if (isVideo) analyzeVideo(context, uri, selectedGeneral, selectedGame)
                    else analyzeImage(context, uri, selectedGeneral, selectedGame)
                }.getOrElse { error ->
                    VisionUiState("Could not analyze file", error.message ?: "The selected file could not be decoded.")
                }
            }
            state = result
        }
    }

    fun pickModel(uri: Uri?, slot: String) {
        if (uri == null) return
        state = state.copy(title = "Validating $slot model…", busy = true)
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val directory = File(context.filesDir, "vision_models").apply { mkdirs() }
                    val target = File(directory, if (slot == "general") "general-detector.tflite" else "game-detector.tflite")
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        FileOutputStream(target).use { output -> input.copyTo(output) }
                    } ?: error("Could not read the selected model file.")
                    LocalObjectDetector.load(context, target).use { it.modelName }
                    target.absolutePath
                }
            }
            result.onSuccess { path ->
                if (slot == "general") {
                    generalModelPath = path
                    modelPreferences.edit().putString("general_model_path", path).apply()
                } else {
                    gameModelPath = path
                    modelPreferences.edit().putString("game_model_path", path).apply()
                }
                modelName = "General: ${generalModelPath?.let { File(it).name } ?: "not loaded"} · Game-specific: ${gameModelPath?.let { File(it).name } ?: "not loaded"}"
                state = VisionUiState("Local model ready", "The $slot model validated. You can load the other model too; both run locally.")
            }.onFailure { error ->
                state = VisionUiState("Model could not be loaded", error.message ?: "Choose a TensorFlow Lite Task Vision detector with metadata and labels.")
            }
        }
    }
    val generalModelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { pickModel(it, "general") }
    val gameModelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { pickModel(it, "game") }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) analyze(uri, false)
    }
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) analyze(uri, true)
    }

    Column(
        Modifier.fillMaxSize().padding(22.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("QUEST VISUAL LAB", style = MaterialTheme.typography.headlineMedium)
        Text("Local perception · dual-model prototype 0.6", style = MaterialTheme.typography.labelLarge)
        Text(
            "Detection models: $modelName",
            style = MaterialTheme.typography.bodySmall
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { generalModelPicker.launch(arrayOf("*/*")) }, enabled = !state.busy) {
                Text("Load general model")
            }
            Button(onClick = { gameModelPicker.launch(arrayOf("*/*")) }, enabled = !state.busy) {
                Text("Load game model")
            }
            Button(onClick = { imagePicker.launch(arrayOf("image/*")) }, enabled = !state.busy) {
                Text("Screenshot")
            }
            Button(onClick = { videoPicker.launch(arrayOf("video/*")) }, enabled = !state.busy) {
                Text("Video")
            }
        }
        if (state.busy) Text("Processing on this headset…")
        Text(state.title, style = MaterialTheme.typography.titleLarge)
        Text(state.summary, style = MaterialTheme.typography.bodyMedium)

        if (state.assessment.isNotBlank()) {
            Surface(shape = MaterialTheme.shapes.medium, tonalElevation = 2.dp) {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("LIV scene assessment", style = MaterialTheme.typography.titleMedium)
                    Text(state.assessment)
                    Text("Mean model confidence: ${(state.confidence * 100).toInt()}%", style = MaterialTheme.typography.labelMedium)
                }
            }
        }

        if (state.detections.isNotEmpty()) {
            Text("Tracked objects", style = MaterialTheme.typography.titleMedium)
            LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                items(state.detections) { item ->
                    Text(
                        "#${item.id} · ${item.label} [${item.modelSource}] · ${(item.confidence * 100).toInt()}% · ${item.consecutiveFrames} frame(s) · box ${item.bounds.left.toInt()},${item.bounds.top.toInt()}–${item.bounds.right.toInt()},${item.bounds.bottom.toInt()}",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        } else if (state.regions.isNotEmpty()) {
            Text(if (state.mapUsesEdges) "Screenshot structure map" else "Video change map", style = MaterialTheme.typography.titleMedium)
            Text(
                if (state.mapUsesEdges) "Brighter cells contain stronger local edges and contrast."
                else "Brighter cells show more pixel change. They are not enemy markers."
            )
            LazyVerticalGrid(
                columns = GridCells.Fixed(8),
                modifier = Modifier.fillMaxWidth().weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                gridItems(state.regions) { region ->
                    val metric = if (state.mapUsesEdges) region.edgeStrength else region.changeScore
                    val intensity = (metric / 80f).coerceIn(0f, 1f)
                    Column(
                        Modifier.aspectRatio(1f)
                            .background(
                                Color(
                                    red = 0.12f + intensity * 0.75f,
                                    green = 0.18f + intensity * 0.35f,
                                    blue = 0.25f
                                ),
                                RoundedCornerShape(4.dp)
                            ).padding(3.dp)
                    ) {
                        Text("${region.column},${region.row}", color = Color.White, fontSize = 8.sp)
                    }
                }
            }
        }

        Text(
            "Model note: no weights are bundled. Import a general detector and/or a game-specific detector. Game-specific detections take priority when boxes overlap; source tags remain visible. Neither model can infer team or hostile intent without validated labels and evidence.",
            style = MaterialTheme.typography.labelSmall
        )
        Text(
            "All analysis and visual memory stay on-device. Imported clips are sampled locally and are not uploaded.",
            style = MaterialTheme.typography.labelSmall
        )
    }
}

private fun analyzeImage(context: Context, uri: Uri, generalModelFile: File?, gameModelFile: File?): VisionUiState {
    val bitmap = openScaledBitmap(context, uri) ?: error("This image format could not be decoded.")
    try {
        val report = VisualFrameAnalyzer().analyze(bitmap)
        if (generalModelFile == null && gameModelFile == null) {
            return VisionUiState(
                "Screenshot analyzed · ${report.width} × ${report.height}",
                "Image structure: ${report.highContrastRegions} of 48 grid cells contain stronger edges. Load a local object-detection model to recognize labeled objects.",
                report.regions,
                mapUsesEdges = true
            )
        }
        val detections = VisionModelRouter(
            generalModelFile?.let { LocalObjectDetector.load(context, it) },
            gameModelFile?.let { LocalObjectDetector.load(context, it) }
        ).use { it.detect(bitmap) }
        val tracked = detections.mapIndexed { index, item ->
            TrackedObject(index + 1, item.label, item.confidence, item.bounds, 1, item.modelSource)
        }
        val assessment = TacticalVisualInterpreter().assess(tracked)
        val summary = buildAssessmentText(assessment)
        LocalVisualMemory(context).record(summary, assessment.confidence)
        TacticalCoach(context).recordVisualObservation(summary)
        return VisionUiState(
            "Screenshot analyzed · ${report.width} × ${report.height}",
            "Single-frame detections are provisional; tracking confidence requires multiple frames.",
            report.regions,
            mapUsesEdges = true,
            detections = tracked,
            assessment = assessment.headline + ". " + assessment.details.joinToString(" ") + " " + assessment.caution,
            confidence = assessment.confidence
        )
    } finally {
        bitmap.recycle()
    }
}

private fun analyzeVideo(context: Context, uri: Uri, generalModelFile: File?, gameModelFile: File?): VisionUiState {
    val retriever = MediaMetadataRetriever()
    try {
        retriever.setDataSource(context, uri)
        val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
            ?: error("Video duration is unavailable.")
        if (durationMs <= 0L) error("The selected video has no readable duration.")

        val analyzer = VisualFrameAnalyzer()
        val accumulated = FloatArray(48)
        val tracker = ObjectTrackManager()
        val cameraEstimator = CameraMotionEstimator()
        var comparisons = 0
        var firstWidth = 0
        var firstHeight = 0
        var latestTracks = emptyList<TrackedObject>()
        var totalCameraConfidence = 0f
        var cameraEstimates = 0
        var previous: Bitmap? = null
        val frameCount = min(10, max(2, (durationMs / 700L).toInt()))
        val detector = if (generalModelFile == null && gameModelFile == null) null else VisionModelRouter(
            generalModelFile?.let { LocalObjectDetector.load(context, it) },
            gameModelFile?.let { LocalObjectDetector.load(context, it) }
        )
        try {
            for (i in 0 until frameCount) {
                val timeMs = (durationMs - 1L) * i / (frameCount - 1)
                val frame = retriever.getFrameAtTime(timeMs * 1000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    ?: continue
                val scaled = scaleBitmap(frame)
                if (firstWidth == 0) {
                    firstWidth = scaled.width
                    firstHeight = scaled.height
                }
                val prior = previous
                var shift = CameraShift(0f, 0f, 0f)
                if (prior != null && prior.width == scaled.width && prior.height == scaled.height) {
                    val report = analyzer.analyze(scaled, prior)
                    report.regions.forEachIndexed { index, region -> accumulated[index] += region.changeScore }
                    comparisons++
                    shift = cameraEstimator.estimate(prior, scaled)
                    totalCameraConfidence += shift.confidence
                    cameraEstimates++
                }
                if (detector != null) {
                    val detections = detector.detect(scaled)
                    latestTracks = tracker.update(detections, shift)
                }
                previous?.recycle()
                previous = scaled
            }
        } finally {
            previous?.recycle()
            detector?.close()
        }
        if (comparisons == 0) error("No comparable frames could be extracted from this clip.")
        val regions = accumulated.mapIndexed { index, total ->
            VisualRegion(index % 8, index / 8, 0f, 0f, total / comparisons)
        }
        val changed = regions.count { it.changeScore >= 18f }
        if (generalModelFile == null && gameModelFile == null) {
            return VisionUiState(
                "Video sampled · $comparisons frame comparisons",
                "Decoded frames at up to $firstWidth × $firstHeight. $changed of 48 grid cells showed notable average pixel change. Load a local object-detection model to recognize objects.",
                regions
            )
        }

        val assessment = TacticalVisualInterpreter().assess(latestTracks)
        val cameraConfidence = if (cameraEstimates == 0) 0f else totalCameraConfidence / cameraEstimates
        val summary = buildAssessmentText(assessment) +
            " Camera-motion estimate confidence: ${(cameraConfidence * 100).toInt()}%."
        LocalVisualMemory(context).record(summary, assessment.confidence)
        TacticalCoach(context).recordVisualObservation(summary)
        return VisionUiState(
            "Video analyzed · $comparisons frame comparisons",
            "Sampled $frameCount timestamps at up to $firstWidth × $firstHeight. Camera-motion compensation is a coarse 2D translation estimate; it is not headset pose tracking.",
            regions,
            detections = latestTracks,
            assessment = assessment.headline + ". " + assessment.details.joinToString(" ") +
                " Camera-shift estimate confidence: ${(cameraConfidence * 100).toInt()}%. " + assessment.caution,
            confidence = assessment.confidence
        )
    } finally {
        retriever.release()
    }
}

private fun buildAssessmentText(assessment: TacticalVisualAssessment): String =
    assessment.headline + ". " + assessment.details.joinToString(" ") + " " + assessment.caution

private fun openScaledBitmap(context: Context, uri: Uri): Bitmap? {
    val source = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return null
    return scaleBitmap(source)
}

private fun scaleBitmap(source: Bitmap): Bitmap {
    val maxDimension = 640
    val largest = max(source.width, source.height)
    if (largest <= maxDimension) return source
    val ratio = maxDimension.toFloat() / largest.toFloat()
    val scaled = Bitmap.createScaledBitmap(
        source,
        max(1, (source.width * ratio).toInt()),
        max(1, (source.height * ratio).toInt()),
        true
    )
    source.recycle()
    return scaled
}
