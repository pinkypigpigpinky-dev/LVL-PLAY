package com.lvl.play.speech

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.content.ContextCompat
import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.OfflineTtsConfig
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsVitsModelConfig
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/**
 * LIV's bundled, fully offline voice.
 *
 * Piper Alba is a British English female voice model shipped in the APK.
 * sherpa-onnx synthesizes speech locally; Android's online TTS engines are
 * never used. Speech recognition remains on-device Android recognition.
 */
class LocalLivSpeech(context: Context) : AutoCloseable {
    private val appContext = context.applicationContext
    private val synthesisExecutor = Executors.newSingleThreadExecutor()
    private val generationId = AtomicInteger(0)
    private var tts: OfflineTts? = null
    private var activeTrack: AudioTrack? = null
    private var recognizer: SpeechRecognizer? = null

    @Volatile private var ready = false
    @Volatile private var selectedVoiceName: String? = null

    companion object {
        private const val UTTERANCE_ID = "liv-bundled-alba"
        private const val MAX_SPOKEN_CHARACTERS = 1200
        private const val VOICE_ASSET_DIR = "liv_voice"
        private const val VOICE_MODEL = "en_GB-alba-medium-int8.onnx"
    }

    init {
        synthesisExecutor.execute {
            try {
                val modelDir = File(appContext.filesDir, VOICE_ASSET_DIR)
                copyAssetsRecursively(VOICE_ASSET_DIR, modelDir)
                val modelFile = File(modelDir, VOICE_MODEL)
                val tokensFile = File(modelDir, "tokens.txt")
                val espeakDir = File(modelDir, "espeak-ng-data")
                check(modelFile.isFile && tokensFile.isFile && espeakDir.isDirectory) {
                    "Bundled LIV voice files are incomplete"
                }

                val config = OfflineTtsConfig(
                    model = OfflineTtsModelConfig(
                        vits = OfflineTtsVitsModelConfig(
                            model = modelFile.absolutePath,
                            tokens = tokensFile.absolutePath,
                            dataDir = espeakDir.absolutePath
                        ),
                        numThreads = 2,
                        debug = false,
                        provider = "cpu"
                    )
                )
                tts = OfflineTts(config = config)
                selectedVoiceName = "Piper Alba — British English female (bundled/offline)"
                ready = true
            } catch (error: Throwable) {
                ready = false
                selectedVoiceName = null
                android.util.Log.e("LIV_SPEECH", "Could not initialize bundled Alba voice", error)
            }
        }
    }

    private fun copyAssetsRecursively(assetPath: String, destination: File) {
        val children = appContext.assets.list(assetPath).orEmpty()
        if (children.isNotEmpty()) {
            if (!destination.exists()) destination.mkdirs()
            children.forEach { child ->
                copyAssetsRecursively("$assetPath/$child", File(destination, child))
            }
            return
        }

        destination.parentFile?.mkdirs()
        appContext.assets.open(assetPath).use { input ->
            FileOutputStream(destination).use { output -> input.copyTo(output) }
        }
    }

    fun speak(text: String): Boolean {
        val cleanText = text.trim().take(MAX_SPOKEN_CHARACTERS)
        if (!ready || cleanText.isBlank()) return false
        val requestId = generationId.incrementAndGet()
        return try {
            synthesisExecutor.execute {
                try {
                    val audio = tts?.generate(cleanText, sid = 0, speed = 0.96f) ?: return@execute
                    if (generationId.get() != requestId || audio.samples.isEmpty()) return@execute
                    stopTrack()
                    val track = AudioTrack.Builder()
                        .setAudioAttributes(
                            AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                                .build()
                        )
                        .setAudioFormat(
                            AudioFormat.Builder()
                                .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                                .setSampleRate(audio.sampleRate)
                                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                                .build()
                        )
                        .setTransferMode(AudioTrack.MODE_STATIC)
                        .setBufferSizeInBytes(audio.samples.size * Float.SIZE_BYTES)
                        .build()
                    activeTrack = track
                    track.setNotificationMarkerPosition(audio.samples.size)
                    track.setPlaybackPositionUpdateListener(object : AudioTrack.OnPlaybackPositionUpdateListener {
                        override fun onMarkerReached(player: AudioTrack) {
                            synchronized(this@LocalLivSpeech) {
                                if (activeTrack === player) activeTrack = null
                            }
                            player.release()
                        }
                        override fun onPeriodicNotification(player: AudioTrack) = Unit
                    })
                    val written = track.write(audio.samples, 0, audio.samples.size, AudioTrack.WRITE_BLOCKING)
                    if (written > 0 && generationId.get() == requestId) track.play()
                    else stopTrack()
                } catch (error: Throwable) {
                    android.util.Log.e("LIV_SPEECH", "Bundled voice synthesis failed", error)
                    stopTrack()
                }
            }
            true
        } catch (_: java.util.concurrent.RejectedExecutionException) {
            false
        }
    }

    @Synchronized
    private fun stopTrack() {
        val track = activeTrack
        activeTrack = null
        try {
            track?.pause()
            track?.flush()
            track?.release()
        } catch (_: IllegalStateException) {
            // The playback completion callback may have released it already.
        }
    }

    fun stopSpeaking() {
        generationId.incrementAndGet()
        stopTrack()
    }

    fun isReady(): Boolean = ready

    /** Returns the actual bundled voice identity after the model is loaded. */
    fun selectedVoice(): String? = selectedVoiceName

    /**
     * Starts one on-device recognition turn. The caller must obtain RECORD_AUDIO
     * permission after a clear user action. No network recognizer fallback.
     */
    fun listen(onText: (String) -> Unit, onUnavailable: (String) -> Unit): Boolean {
        if (ContextCompat.checkSelfPermission(appContext, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            onUnavailable("Microphone permission has not been granted.")
            return false
        }
        if (!SpeechRecognizer.isOnDeviceRecognitionAvailable(appContext)) {
            onUnavailable("No on-device speech recognition service is installed.")
            return false
        }
        return try {
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(appContext).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) = Unit
                    override fun onBeginningOfSpeech() = Unit
                    override fun onRmsChanged(rmsdB: Float) = Unit
                    override fun onBufferReceived(buffer: ByteArray?) = Unit
                    override fun onEndOfSpeech() = Unit
                    override fun onError(error: Int) {
                        onUnavailable("On-device recognition error: $error")
                    }
                    override fun onResults(results: Bundle?) {
                        val text = results
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()
                            .orEmpty()
                        if (text.isNotBlank()) onText(text)
                        else onUnavailable("No speech was recognized.")
                    }
                    override fun onPartialResults(partialResults: Bundle?) = Unit
                    override fun onEvent(eventType: Int, params: Bundle?) = Unit
                })
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.UK.toLanguageTag())
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                    putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                }
                startListening(intent)
            }
            true
        } catch (error: UnsupportedOperationException) {
            onUnavailable("On-device recognition is unsupported on this headset.")
            false
        } catch (error: SecurityException) {
            onUnavailable("Microphone permission is unavailable.")
            false
        }
    }

    fun stopListening() {
        recognizer?.cancel()
        recognizer?.destroy()
        recognizer = null
    }

    override fun close() {
        ready = false
        selectedVoiceName = null
        generationId.incrementAndGet()
        stopListening()
        stopTrack()
        synthesisExecutor.execute {
            tts?.release()
            tts = null
        }
        synthesisExecutor.shutdown()
    }
}
