package com.lvl.play.coach

import android.content.Context
import com.lvl.play.vision.LocalVisualMemory

/**
 * Offline tactical coaching core for the standalone Quest companion.
 *
 * Deterministic first-stage coaching, not a bundled language model. It reasons
 * only from player-provided context and local notes; it never claims live vision.
 */
class TacticalCoach(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences("liv_tactical_memory", Context.MODE_PRIVATE)

    fun respond(raw: String): String {
        val input = raw.trim().lowercase()
        if (input.isBlank()) return "I didn't catch that. Tell me what's happening, or ask for a tactical tip."

        when {
            containsAny(input, "what did you see", "latest visual", "visual analysis", "what did the camera see") -> {
                val observation = prefs.getString("last_visual_observation", null)
                return observation ?: "I don't have a saved visual-analysis result yet. Analyze an imported clip in Quest Visual Lab first."
            }
            containsAny(input, "forget visual memory", "clear visual memory") -> {
                prefs.edit().remove("last_visual_observation").apply()
                LocalVisualMemory(appContext).clear()
                return "I've cleared the saved visual-analysis history and the latest summary on this headset."
            }
            containsAny(input, "forget my loadout", "clear my loadout") -> {
                prefs.edit().remove("loadout_note").apply()
                return "Okay. I've cleared your saved loadout note from this headset."
            }
            containsAny(input, "forget my preferences", "forget my strategy", "clear my notes") -> {
                prefs.edit().remove("loadout_note").remove("strategy_note").apply()
                return "Okay. I've cleared your saved tactical notes from this headset."
            }
            containsAny(input, "what do you remember", "what is my loadout", "my preferences", "show my loadout") -> {
                val loadout = prefs.getString("loadout_note", null)
                val strategy = prefs.getString("strategy_note", null)
                if (loadout == null && strategy == null) {
                    return "I don't have any saved tactical preferences yet. Tell me your usual loadout or strategy and I'll remember it locally."
                }
                return buildString {
                    append("Here's what I have saved on this headset. ")
                    if (loadout != null) append("Loadout: $loadout. ")
                    if (strategy != null) append("Strategy: $strategy.")
                }
            }
            containsAny(input, "my loadout is", "i use", "my weapon is") -> {
                val value = raw.trim().take(180)
                prefs.edit().putString("loadout_note", value).apply()
                return "Got it. I'll remember this loadout on this headset: $value. Tell me when you change it."
            }
            containsAny(input, "remember", "my strategy is", "i prefer") -> {
                val value = raw.trim().take(180)
                prefs.edit().putString("strategy_note", value).apply()
                return "I'll keep that preference locally on this headset: $value."
            }
            containsAny(input, "rocket jump", "rocketjump", "jump") ->
                return "For a rocket jump, check your health and escape route first. Aim the blast at the ground or a nearby surface, jump and fire with tight timing, then steer with controlled air movement. Don't trade all your health for height when a safer route is available."
            containsAny(input, "direct hit", "aim", "miss", "shot") ->
                return "Lead moving targets rather than chasing their current position. Favor predictable landings, doorways, and exposed crossings. Take the shot when your aim settles; don't stay exposed just to force it."
            containsAny(input, "low health", "hurt", "healing", "health") ->
                return "Break line of sight and use cover before re-engaging. Avoid crossing open lanes while low. If a teammate or safe route is available, prioritize surviving over one more shot."
            containsAny(input, "enemy", "where are", "threat", "surrounded", "behind me") ->
                return "I can't see your live game view in standalone Quest mode, so I won't invent an enemy marker. Check your flanks and nearby cover, listen for directional audio, and tell me what you can see; I'll help assess the threat."
            containsAny(input, "strategy", "what should i do", "help me", "what now", "advice") ->
                return "Play around cover, keep an escape route, and avoid re-peeking the same angle after firing. Tell me your class, weapon, health, and what the other team is doing for a more specific call."
            containsAny(input, "hello", "hi liv", "hey liv") ->
                return "Hey. I'm here. I can help plan your next move, review a situation you describe, and remember your tactical preferences locally."
            else ->
                return "I'm listening. I can help with positioning, aim, rocket-jump planning, survival, and loadout strategy. I don't have live enemy vision in standalone mode, so describe the situation and I'll reason from what you tell me."
        }
    }

    fun recordVisualObservation(summary: String) {
        prefs.edit().putString("last_visual_observation", summary.take(700)).apply()
    }

    private fun containsAny(text: String, vararg terms: String): Boolean =
        terms.any { text.contains(it) }
}
