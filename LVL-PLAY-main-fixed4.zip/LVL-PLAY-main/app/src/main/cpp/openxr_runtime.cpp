#define XR_USE_PLATFORM_ANDROID
#define XR_USE_GRAPHICS_API_OPENGL_ES

// openxr_platform.h uses Android JNI and EGL types, so their headers must
// be visible before the platform extension declarations are parsed.
#include <jni.h>
#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <GLES3/gl3.h>

#include <openxr/openxr.h>
#include <openxr/openxr_platform.h>
#include <android/log.h>

#include <atomic>
#include <thread>
#include <chrono>
#include <utility>
#include <vector>
#include <string>
#include <cstring>

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "LIVPLAY_XR", __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "LIVPLAY_XR", __VA_ARGS__)

namespace {
JavaVM* gVm = nullptr;
std::atomic<bool> gStop{false};
std::thread gRenderThread;
 jobject gActivity = nullptr;

struct EyeSwapchain {
    XrSwapchain handle{XR_NULL_HANDLE};
    int32_t width{0};
    int32_t height{0};
    std::vector<XrSwapchainImageOpenGLESKHR> images;
};

struct Runtime {
    XrInstance instance{XR_NULL_HANDLE};
    XrSystemId systemId{XR_NULL_SYSTEM_ID};
    XrSession session{XR_NULL_HANDLE};
    XrActionSet actionSet{XR_NULL_HANDLE};
    XrAction rightAButton{XR_NULL_HANDLE};
    XrSpace space{XR_NULL_HANDLE};
    XrSessionState sessionState{XR_SESSION_STATE_UNKNOWN};
    EGLDisplay display{EGL_NO_DISPLAY};
    EGLConfig config{nullptr};
    EGLContext context{EGL_NO_CONTEXT};
    EGLSurface surface{EGL_NO_SURFACE};
    std::vector<EyeSwapchain> eyes;
    EyeSwapchain hud;
    std::vector<XrView> views;
    std::vector<XrCompositionLayerProjectionView> projectionViews;
    bool sessionRunning{false};
    bool hudEnabled{true};
};

bool ok(XrResult result, const char* operation) {
    if (XR_SUCCEEDED(result)) return true;
    LOGE("%s failed: %d", operation, result);
    return false;
}

void destroy(Runtime& r) {
    if (r.sessionRunning && r.session != XR_NULL_HANDLE) {
        xrEndSession(r.session);
        r.sessionRunning = false;
    }
    if (r.hud.handle != XR_NULL_HANDLE) {
        xrDestroySwapchain(r.hud.handle);
        r.hud.handle = XR_NULL_HANDLE;
    }
    for (auto& eye : r.eyes) {
        if (eye.handle != XR_NULL_HANDLE) xrDestroySwapchain(eye.handle);
    }
    r.eyes.clear();
    if (r.space != XR_NULL_HANDLE) xrDestroySpace(r.space);
    if (r.session != XR_NULL_HANDLE) xrDestroySession(r.session);
    if (r.actionSet != XR_NULL_HANDLE) {
        xrDestroyActionSet(r.actionSet);
        r.actionSet = XR_NULL_HANDLE;
    }
    if (r.instance != XR_NULL_HANDLE) xrDestroyInstance(r.instance);
    if (r.display != EGL_NO_DISPLAY) {
        if (r.surface != EGL_NO_SURFACE) eglDestroySurface(r.display, r.surface);
        if (r.context != EGL_NO_CONTEXT) eglDestroyContext(r.display, r.context);
        eglTerminate(r.display);
    }
    r = Runtime{};
}

bool initializeLoader(JNIEnv* env, jobject activity) {
    PFN_xrInitializeLoaderKHR initializeLoader = nullptr;
    if (!ok(xrGetInstanceProcAddr(XR_NULL_HANDLE, "xrInitializeLoaderKHR",
            reinterpret_cast<PFN_xrVoidFunction*>(&initializeLoader)),
            "xrGetInstanceProcAddr(xrInitializeLoaderKHR)")) return false;

    XrLoaderInitInfoAndroidKHR loaderInfo{XR_TYPE_LOADER_INIT_INFO_ANDROID_KHR};
    loaderInfo.applicationVM = gVm;
    // The OpenXR struct stores this as void*, but JNI owns it as a jobject.
    // Keep the typed reference so it can be released correctly afterwards.
    jobject applicationContext = env->NewGlobalRef(activity);
    if (applicationContext == nullptr) {
        LOGE("Could not create global Android application context reference");
        return false;
    }
    loaderInfo.applicationContext = applicationContext;
    const bool initialized = ok(initializeLoader(
        reinterpret_cast<const XrLoaderInitInfoBaseHeaderKHR*>(&loaderInfo)),
        "xrInitializeLoaderKHR");
    env->DeleteGlobalRef(applicationContext);
    return initialized;
}

bool createEgl(Runtime& r) {
    r.display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    EGLint major = 0, minor = 0;
    if (r.display == EGL_NO_DISPLAY || !eglInitialize(r.display, &major, &minor)) {
        LOGE("EGL initialization failed"); return false;
    }
    const EGLint configAttributes[] = {
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
        EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 8,
        EGL_DEPTH_SIZE, 0, EGL_STENCIL_SIZE, 0, EGL_NONE
    };
    EGLint count = 0;
    if (!eglChooseConfig(r.display, configAttributes, &r.config, 1, &count) || count < 1) {
        LOGE("No compatible EGL config"); return false;
    }
    const EGLint contextAttributes[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
    r.context = eglCreateContext(r.display, r.config, EGL_NO_CONTEXT, contextAttributes);
    const EGLint surfaceAttributes[] = {EGL_WIDTH, 16, EGL_HEIGHT, 16, EGL_NONE};
    r.surface = eglCreatePbufferSurface(r.display, r.config, surfaceAttributes);
    if (r.context == EGL_NO_CONTEXT || r.surface == EGL_NO_SURFACE ||
        !eglMakeCurrent(r.display, r.surface, r.surface, r.context)) {
        LOGE("EGL context or pbuffer creation failed"); return false;
    }
    return true;
}

bool createInstanceAndSession(Runtime& r, JNIEnv* env, jobject activity) {
    if (!initializeLoader(env, activity) || !createEgl(r)) return false;

    const char* extensions[] = {
        XR_KHR_ANDROID_CREATE_INSTANCE_EXTENSION_NAME,
        XR_KHR_OPENGL_ES_ENABLE_EXTENSION_NAME
    };
    XrInstanceCreateInfoAndroidKHR androidInfo{XR_TYPE_INSTANCE_CREATE_INFO_ANDROID_KHR};
    androidInfo.applicationVM = gVm;
    androidInfo.applicationActivity = activity;

    XrInstanceCreateInfo instanceInfo{XR_TYPE_INSTANCE_CREATE_INFO};
    instanceInfo.next = &androidInfo;
    instanceInfo.enabledExtensionCount = 2;
    instanceInfo.enabledExtensionNames = extensions;
    std::strncpy(instanceInfo.applicationInfo.applicationName, "LIV PLAY", XR_MAX_APPLICATION_NAME_SIZE - 1);
    instanceInfo.applicationInfo.applicationVersion = 2;
    std::strncpy(instanceInfo.applicationInfo.engineName, "LVL", XR_MAX_ENGINE_NAME_SIZE - 1);
    instanceInfo.applicationInfo.engineVersion = 1;
    instanceInfo.applicationInfo.apiVersion = XR_MAKE_VERSION(1, 0, 0);
    if (!ok(xrCreateInstance(&instanceInfo, &r.instance), "xrCreateInstance")) return false;

    // Right Touch controller A button: three deliberate presses toggle the
    // in-app HUD and its demo markers. This action is available only while
    // LIV PLAY owns the focused OpenXR session.
    XrPath rightHandPath = XR_NULL_PATH;
    XrPath rightAPath = XR_NULL_PATH;
    XrPath touchProfilePath = XR_NULL_PATH;
    if (!ok(xrStringToPath(r.instance, "/user/hand/right", &rightHandPath), "right hand path") ||
        !ok(xrStringToPath(r.instance, "/user/hand/right/input/a/click", &rightAPath), "right A path") ||
        !ok(xrStringToPath(r.instance, "/interaction_profiles/oculus/touch_controller", &touchProfilePath), "Touch profile path")) return false;

    XrActionSetCreateInfo actionSetInfo{XR_TYPE_ACTION_SET_CREATE_INFO};
    std::strncpy(actionSetInfo.actionSetName, "liv_controls", XR_MAX_ACTION_SET_NAME_SIZE - 1);
    std::strncpy(actionSetInfo.localizedActionSetName, "LIV Controls", XR_MAX_LOCALIZED_ACTION_SET_NAME_SIZE - 1);
    actionSetInfo.priority = 0;
    if (!ok(xrCreateActionSet(r.instance, &actionSetInfo, &r.actionSet), "create LIV action set")) return false;

    XrActionCreateInfo actionInfo{XR_TYPE_ACTION_CREATE_INFO};
    std::strncpy(actionInfo.actionName, "toggle_hud_triple_tap", XR_MAX_ACTION_NAME_SIZE - 1);
    std::strncpy(actionInfo.localizedActionName, "Toggle HUD (press A three times)", XR_MAX_LOCALIZED_ACTION_NAME_SIZE - 1);
    actionInfo.actionType = XR_ACTION_TYPE_BOOLEAN_INPUT;
    actionInfo.countSubactionPaths = 1;
    actionInfo.subactionPaths = &rightHandPath;
    if (!ok(xrCreateAction(r.actionSet, &actionInfo, &r.rightAButton), "create right A action")) return false;

    XrActionSuggestedBinding aBinding{r.rightAButton, rightAPath};
    XrInteractionProfileSuggestedBinding suggested{XR_TYPE_INTERACTION_PROFILE_SUGGESTED_BINDING};
    suggested.interactionProfile = touchProfilePath;
    suggested.countSuggestedBindings = 1;
    suggested.suggestedBindings = &aBinding;
    if (!ok(xrSuggestInteractionProfileBindings(r.instance, &suggested), "suggest Touch A binding")) return false;

    XrSystemGetInfo systemInfo{XR_TYPE_SYSTEM_GET_INFO};
    systemInfo.formFactor = XR_FORM_FACTOR_HEAD_MOUNTED_DISPLAY;
    if (!ok(xrGetSystem(r.instance, &systemInfo, &r.systemId), "xrGetSystem")) return false;

    PFN_xrGetOpenGLESGraphicsRequirementsKHR getRequirements = nullptr;
    if (!ok(xrGetInstanceProcAddr(r.instance, "xrGetOpenGLESGraphicsRequirementsKHR",
        reinterpret_cast<PFN_xrVoidFunction*>(&getRequirements)), "get GLES requirements")) return false;
    XrGraphicsRequirementsOpenGLESKHR requirements{XR_TYPE_GRAPHICS_REQUIREMENTS_OPENGL_ES_KHR};
    if (!ok(getRequirements(r.instance, r.systemId, &requirements), "xrGetOpenGLESGraphicsRequirementsKHR")) return false;

    XrGraphicsBindingOpenGLESAndroidKHR graphicsBinding{XR_TYPE_GRAPHICS_BINDING_OPENGL_ES_ANDROID_KHR};
    graphicsBinding.display = r.display;
    graphicsBinding.config = r.config;
    graphicsBinding.context = r.context;
    XrSessionCreateInfo sessionInfo{XR_TYPE_SESSION_CREATE_INFO};
    sessionInfo.next = &graphicsBinding;
    sessionInfo.systemId = r.systemId;
    if (!ok(xrCreateSession(r.instance, &sessionInfo, &r.session), "xrCreateSession")) return false;
    XrSessionActionSetsAttachInfo attachInfo{XR_TYPE_SESSION_ACTION_SETS_ATTACH_INFO};
    attachInfo.countActionSets = 1;
    attachInfo.actionSets = &r.actionSet;
    if (!ok(xrAttachSessionActionSets(r.session, &attachInfo), "attach LIV action set")) return false;

    XrReferenceSpaceCreateInfo spaceInfo{XR_TYPE_REFERENCE_SPACE_CREATE_INFO};
    spaceInfo.referenceSpaceType = XR_REFERENCE_SPACE_TYPE_LOCAL;
    spaceInfo.poseInReferenceSpace.orientation.w = 1.0f;
    if (!ok(xrCreateReferenceSpace(r.session, &spaceInfo, &r.space), "xrCreateReferenceSpace")) return false;

    uint32_t viewCount = 0;
    if (!ok(xrEnumerateViewConfigurationViews(r.instance, r.systemId,
        XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO, 0, &viewCount, nullptr),
        "enumerate view count")) return false;
    if (viewCount != 2) { LOGE("Expected stereo views, got %u", viewCount); return false; }

    std::vector<XrViewConfigurationView> configViews(
        viewCount, {XR_TYPE_VIEW_CONFIGURATION_VIEW});
    if (!ok(xrEnumerateViewConfigurationViews(r.instance, r.systemId,
        XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO, viewCount, &viewCount,
        configViews.data()), "enumerate view configuration")) return false;

    uint32_t formatCount = 0;
    if (!ok(xrEnumerateSwapchainFormats(r.session, 0, &formatCount, nullptr),
        "enumerate swapchain formats")) return false;
    std::vector<int64_t> formats(formatCount);
    if (!ok(xrEnumerateSwapchainFormats(r.session, formatCount, &formatCount,
        formats.data()), "read swapchain formats")) return false;
    int64_t selectedFormat = GL_RGBA8;
    for (const auto format : formats) {
        if (format == GL_SRGB8_ALPHA8) { selectedFormat = format; break; }
        if (format == GL_RGBA8) selectedFormat = format;
    }

    for (const auto& view : configViews) {
        EyeSwapchain eye;
        eye.width = static_cast<int32_t>(view.recommendedImageRectWidth);
        eye.height = static_cast<int32_t>(view.recommendedImageRectHeight);
        XrSwapchainCreateInfo swapInfo{XR_TYPE_SWAPCHAIN_CREATE_INFO};
        swapInfo.usageFlags = XR_SWAPCHAIN_USAGE_COLOR_ATTACHMENT_BIT |
                              XR_SWAPCHAIN_USAGE_SAMPLED_BIT;
        swapInfo.format = selectedFormat;
        swapInfo.sampleCount = 1;
        swapInfo.width = eye.width;
        swapInfo.height = eye.height;
        swapInfo.faceCount = 1;
        swapInfo.arraySize = 1;
        swapInfo.mipCount = 1;
        if (!ok(xrCreateSwapchain(r.session, &swapInfo, &eye.handle), "xrCreateSwapchain")) return false;

        uint32_t imageCount = 0;
        if (!ok(xrEnumerateSwapchainImages(eye.handle, 0, &imageCount, nullptr),
            "enumerate swapchain image count")) return false;
        eye.images.resize(imageCount, {XR_TYPE_SWAPCHAIN_IMAGE_OPENGL_ES_KHR});
        if (!ok(xrEnumerateSwapchainImages(eye.handle, imageCount, &imageCount,
            reinterpret_cast<XrSwapchainImageBaseHeader*>(eye.images.data())),
            "enumerate swapchain images")) return false;
        r.eyes.push_back(std::move(eye));
    }

    r.hud.width = 1024;
    r.hud.height = 512;
    XrSwapchainCreateInfo hudInfo{XR_TYPE_SWAPCHAIN_CREATE_INFO};
    hudInfo.usageFlags = XR_SWAPCHAIN_USAGE_COLOR_ATTACHMENT_BIT | XR_SWAPCHAIN_USAGE_SAMPLED_BIT;
    hudInfo.format = selectedFormat;
    hudInfo.sampleCount = 1;
    hudInfo.width = r.hud.width;
    hudInfo.height = r.hud.height;
    hudInfo.faceCount = 1;
    hudInfo.arraySize = 1;
    hudInfo.mipCount = 1;
    if (!ok(xrCreateSwapchain(r.session, &hudInfo, &r.hud.handle), "create spatial HUD swapchain")) return false;
    uint32_t hudImageCount = 0;
    if (!ok(xrEnumerateSwapchainImages(r.hud.handle, 0, &hudImageCount, nullptr), "enumerate HUD image count")) return false;
    r.hud.images.resize(hudImageCount, {XR_TYPE_SWAPCHAIN_IMAGE_OPENGL_ES_KHR});
    if (!ok(xrEnumerateSwapchainImages(r.hud.handle, hudImageCount, &hudImageCount,
        reinterpret_cast<XrSwapchainImageBaseHeader*>(r.hud.images.data())), "enumerate HUD images")) return false;

    r.views.resize(viewCount, {XR_TYPE_VIEW});
    r.projectionViews.resize(viewCount, {XR_TYPE_COMPOSITION_LAYER_PROJECTION_VIEW});
    LOGI("OpenXR instance, stereo session, local space and eye swapchains created");
    return true;
}

void renderLoop(Runtime& r) {
    int aPressCount = 0;
    auto firstAPress = std::chrono::steady_clock::time_point{};
    if (!eglMakeCurrent(r.display, r.surface, r.surface, r.context)) {
        LOGE("Could not make EGL context current on OpenXR render thread");
        return;
    }
    while (!gStop.load()) {
        XrEventDataBuffer event{XR_TYPE_EVENT_DATA_BUFFER};
        while (xrPollEvent(r.instance, &event) == XR_SUCCESS) {
            if (event.type == XR_TYPE_EVENT_DATA_SESSION_STATE_CHANGED) {
                const auto* changed = reinterpret_cast<const XrEventDataSessionStateChanged*>(&event);
                r.sessionState = changed->state;
                if (r.sessionState == XR_SESSION_STATE_READY && !r.sessionRunning) {
                    XrSessionBeginInfo beginInfo{XR_TYPE_SESSION_BEGIN_INFO};
                    beginInfo.primaryViewConfigurationType = XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO;
                    if (ok(xrBeginSession(r.session, &beginInfo), "xrBeginSession")) r.sessionRunning = true;
                } else if (r.sessionState == XR_SESSION_STATE_STOPPING && r.sessionRunning) {
                    xrEndSession(r.session);
                    r.sessionRunning = false;
                } else if (r.sessionState == XR_SESSION_STATE_EXITING ||
                           r.sessionState == XR_SESSION_STATE_LOSS_PENDING) {
                    gStop.store(true);
                }
            }
            event = {XR_TYPE_EVENT_DATA_BUFFER};
        }

        if (!r.sessionRunning) {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
            continue;
        }

        XrFrameWaitInfo waitInfo{XR_TYPE_FRAME_WAIT_INFO};
        XrFrameState frameState{XR_TYPE_FRAME_STATE};
        if (!ok(xrWaitFrame(r.session, &waitInfo, &frameState), "xrWaitFrame")) break;

        XrActiveActionSet activeActionSet{r.actionSet, XR_NULL_PATH};
        XrActionsSyncInfo syncInfo{XR_TYPE_ACTIONS_SYNC_INFO};
        syncInfo.countActiveActionSets = 1;
        syncInfo.activeActionSets = &activeActionSet;
        if (XR_SUCCEEDED(xrSyncActions(r.session, &syncInfo))) {
            XrActionStateGetInfo getAInfo{XR_TYPE_ACTION_STATE_GET_INFO};
            getAInfo.action = r.rightAButton;
            getAInfo.subactionPath = XR_NULL_PATH;
            XrActionStateBoolean aState{XR_TYPE_ACTION_STATE_BOOLEAN};
            if (XR_SUCCEEDED(xrGetActionStateBoolean(r.session, &getAInfo, &aState)) &&
                aState.isActive && aState.changedSinceLastSync && aState.currentState) {
                const auto now = std::chrono::steady_clock::now();
                if (aPressCount == 0 || now - firstAPress > std::chrono::milliseconds(1500)) {
                    aPressCount = 1;
                    firstAPress = now;
                } else {
                    ++aPressCount;
                }
                if (aPressCount >= 3) {
                    r.hudEnabled = !r.hudEnabled;
                    aPressCount = 0;
                    LOGI("HUD and marker overlay %s after right A triple-tap", r.hudEnabled ? "enabled" : "disabled");
                }
            }
        }

        XrFrameBeginInfo beginInfo{XR_TYPE_FRAME_BEGIN_INFO};
        if (!ok(xrBeginFrame(r.session, &beginInfo), "xrBeginFrame")) break;

        XrCompositionLayerProjection layer{XR_TYPE_COMPOSITION_LAYER_PROJECTION};
        layer.space = r.space;
        bool submitProjection = false;

        if (frameState.shouldRender) {
            XrViewState viewState{XR_TYPE_VIEW_STATE};
            XrViewLocateInfo locateInfo{XR_TYPE_VIEW_LOCATE_INFO};
            locateInfo.viewConfigurationType = XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO;
            locateInfo.displayTime = frameState.predictedDisplayTime;
            locateInfo.space = r.space;
            uint32_t located = 0;
            if (ok(xrLocateViews(r.session, &locateInfo, &viewState,
                static_cast<uint32_t>(r.views.size()), &located, r.views.data()),
                "xrLocateViews") && located == r.eyes.size() &&
                (viewState.viewStateFlags & XR_VIEW_STATE_POSITION_VALID_BIT) &&
                (viewState.viewStateFlags & XR_VIEW_STATE_ORIENTATION_VALID_BIT)) {

                bool allEyesRendered = true;
                for (size_t i = 0; i < r.eyes.size(); ++i) {
                    auto& eye = r.eyes[i];
                    uint32_t imageIndex = 0;
                    XrSwapchainImageAcquireInfo acquire{XR_TYPE_SWAPCHAIN_IMAGE_ACQUIRE_INFO};
                    if (!ok(xrAcquireSwapchainImage(eye.handle, &acquire, &imageIndex), "acquire eye image")) {
                        allEyesRendered = false;
                        break;
                    }
                    XrSwapchainImageWaitInfo imageWait{XR_TYPE_SWAPCHAIN_IMAGE_WAIT_INFO};
                    imageWait.timeout = XR_INFINITE_DURATION;
                    if (!ok(xrWaitSwapchainImage(eye.handle, &imageWait), "wait eye image")) {
                        XrSwapchainImageReleaseInfo release{XR_TYPE_SWAPCHAIN_IMAGE_RELEASE_INFO};
                        xrReleaseSwapchainImage(eye.handle, &release);
                        allEyesRendered = false;
                        break;
                    }

                    GLuint framebuffer = 0;
                    glGenFramebuffers(1, &framebuffer);
                    glBindFramebuffer(GL_FRAMEBUFFER, framebuffer);
                    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0,
                        GL_TEXTURE_2D, eye.images[imageIndex].image, 0);
                    glViewport(0, 0, eye.width, eye.height);
                    glClearColor(0.012f, 0.018f, 0.035f, 1.0f);
                    glClear(GL_COLOR_BUFFER_BIT);
                    const bool framebufferComplete = glCheckFramebufferStatus(GL_FRAMEBUFFER) == GL_FRAMEBUFFER_COMPLETE;
                    glBindFramebuffer(GL_FRAMEBUFFER, 0);
                    glDeleteFramebuffers(1, &framebuffer);

                    XrSwapchainImageReleaseInfo release{XR_TYPE_SWAPCHAIN_IMAGE_RELEASE_INFO};
                    if (!ok(xrReleaseSwapchainImage(eye.handle, &release), "release eye image") || !framebufferComplete) {
                        allEyesRendered = false;
                        break;
                    }

                    auto& projectionView = r.projectionViews[i];
                    projectionView.pose = r.views[i].pose;
                    projectionView.fov = r.views[i].fov;
                    projectionView.subImage.swapchain = eye.handle;
                    projectionView.subImage.imageRect.offset = {0, 0};
                    projectionView.subImage.imageRect.extent = {eye.width, eye.height};
                    projectionView.subImage.imageArrayIndex = 0;
                }
                if (allEyesRendered) {
                    layer.viewCount = static_cast<uint32_t>(r.projectionViews.size());
                    layer.views = r.projectionViews.data();
                    submitProjection = true;
                }
            }
        }

        bool submitHud = false;
        if (frameState.shouldRender && r.hudEnabled) {
            uint32_t hudIndex = 0;
            XrSwapchainImageAcquireInfo acquire{XR_TYPE_SWAPCHAIN_IMAGE_ACQUIRE_INFO};
            if (ok(xrAcquireSwapchainImage(r.hud.handle, &acquire, &hudIndex), "acquire HUD image")) {
                XrSwapchainImageWaitInfo wait{XR_TYPE_SWAPCHAIN_IMAGE_WAIT_INFO};
                wait.timeout = XR_INFINITE_DURATION;
                if (ok(xrWaitSwapchainImage(r.hud.handle, &wait), "wait HUD image")) {
                    GLuint framebuffer = 0;
                    glGenFramebuffers(1, &framebuffer);
                    glBindFramebuffer(GL_FRAMEBUFFER, framebuffer);
                    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D,
                        r.hud.images[hudIndex].image, 0);
                    glViewport(0, 0, r.hud.width, r.hud.height);
                    // Alpha-composited tactical HUD demo. These are deliberately
                    // labeled training/demo graphics, never claims of live enemy data.
                    glDisable(GL_SCISSOR_TEST);
                    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
                    glClear(GL_COLOR_BUFFER_BIT);
                    glEnable(GL_SCISSOR_TEST);

                    // Top status strip and left/right information cards.
                    glScissor(24, 452, 976, 44);
                    glClearColor(0.025f, 0.12f, 0.17f, 0.88f);
                    glClear(GL_COLOR_BUFFER_BIT);
                    glScissor(48, 344, 350, 82);
                    glClearColor(0.025f, 0.055f, 0.085f, 0.78f);
                    glClear(GL_COLOR_BUFFER_BIT);
                    glScissor(626, 344, 350, 82);
                    glClearColor(0.025f, 0.055f, 0.085f, 0.78f);
                    glClear(GL_COLOR_BUFFER_BIT);
                    glScissor(48, 58, 928, 66);
                    glClearColor(0.025f, 0.055f, 0.085f, 0.82f);
                    glClear(GL_COLOR_BUFFER_BIT);

                    // Demo enemy marker: red bracket/crosshair around a sample target.
                    glScissor(482, 258, 60, 5);
                    glClearColor(1.0f, 0.20f, 0.16f, 1.0f);
                    glClear(GL_COLOR_BUFFER_BIT);
                    glScissor(482, 202, 60, 5);
                    glClear(GL_COLOR_BUFFER_BIT);
                    glScissor(482, 202, 5, 61);
                    glClear(GL_COLOR_BUFFER_BIT);
                    glScissor(537, 202, 5, 61);
                    glClear(GL_COLOR_BUFFER_BIT);
                    glScissor(508, 222, 8, 25);
                    glClear(GL_COLOR_BUFFER_BIT);
                    glScissor(500, 230, 24, 8);
                    glClear(GL_COLOR_BUFFER_BIT);

                    // Directional threat tick and helper recommendation rail.
                    glScissor(492, 410, 40, 5);
                    glClearColor(1.0f, 0.62f, 0.12f, 1.0f);
                    glClear(GL_COLOR_BUFFER_BIT);
                    glScissor(48, 82, 520, 8);
                    glClearColor(0.12f, 0.72f, 0.82f, 0.95f);
                    glClear(GL_COLOR_BUFFER_BIT);
                    glDisable(GL_SCISSOR_TEST);
                    glBindFramebuffer(GL_FRAMEBUFFER, 0);
                    glDeleteFramebuffers(1, &framebuffer);
                    XrSwapchainImageReleaseInfo release{XR_TYPE_SWAPCHAIN_IMAGE_RELEASE_INFO};
                    submitHud = ok(xrReleaseSwapchainImage(r.hud.handle, &release), "release HUD image");
                } else {
                    XrSwapchainImageReleaseInfo release{XR_TYPE_SWAPCHAIN_IMAGE_RELEASE_INFO};
                    xrReleaseSwapchainImage(r.hud.handle, &release);
                }
            }
        }

        XrCompositionLayerQuad hudLayer{XR_TYPE_COMPOSITION_LAYER_QUAD};
        hudLayer.space = r.space;
        hudLayer.layerFlags = XR_COMPOSITION_LAYER_BLEND_TEXTURE_SOURCE_ALPHA_BIT;
        hudLayer.eyeVisibility = XR_EYE_VISIBILITY_BOTH;
        hudLayer.subImage.swapchain = r.hud.handle;
        hudLayer.subImage.imageRect.offset = {0, 0};
        hudLayer.subImage.imageRect.extent = {r.hud.width, r.hud.height};
        hudLayer.subImage.imageArrayIndex = 0;
        hudLayer.pose.orientation.w = 1.0f;
        hudLayer.pose.position = {0.0f, 0.0f, -1.35f};
        hudLayer.size = {1.25f, 0.625f};

        const XrCompositionLayerBaseHeader* layers[] = {
            reinterpret_cast<const XrCompositionLayerBaseHeader*>(&layer),
            reinterpret_cast<const XrCompositionLayerBaseHeader*>(&hudLayer)
        };
        XrFrameEndInfo endInfo{XR_TYPE_FRAME_END_INFO};
        endInfo.displayTime = frameState.predictedDisplayTime;
        endInfo.environmentBlendMode = XR_ENVIRONMENT_BLEND_MODE_OPAQUE;
        endInfo.layerCount = (submitProjection ? 1u : 0u) + ((submitHud && r.hudEnabled) ? 1u : 0u);
        if (submitProjection && submitHud) {
            endInfo.layers = layers;
        } else if (submitProjection) {
            endInfo.layers = layers;
        } else if (submitHud) {
            endInfo.layers = &layers[1];
        } else {
            endInfo.layers = nullptr;
        }
        if (!ok(xrEndFrame(r.session, &endInfo), "xrEndFrame")) break;
    }
    if (r.sessionRunning) {
        xrRequestExitSession(r.session);
        const auto deadline = std::chrono::steady_clock::now() + std::chrono::milliseconds(500);
        while (r.sessionRunning && std::chrono::steady_clock::now() < deadline) {
            XrEventDataBuffer stopEvent{XR_TYPE_EVENT_DATA_BUFFER};
            while (xrPollEvent(r.instance, &stopEvent) == XR_SUCCESS) {
                if (stopEvent.type == XR_TYPE_EVENT_DATA_SESSION_STATE_CHANGED) {
                    const auto* changed = reinterpret_cast<const XrEventDataSessionStateChanged*>(&stopEvent);
                    r.sessionState = changed->state;
                    if (r.sessionState == XR_SESSION_STATE_STOPPING) {
                        if (ok(xrEndSession(r.session), "xrEndSession")) r.sessionRunning = false;
                    }
                }
                stopEvent = {XR_TYPE_EVENT_DATA_BUFFER};
            }
            if (r.sessionRunning) std::this_thread::sleep_for(std::chrono::milliseconds(2));
        }
    }
    eglMakeCurrent(r.display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
}
} // namespace

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void*) {
    gVm = vm;
    return JNI_VERSION_1_6;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_lvl_play_OpenXrActivity_nativeStart(JNIEnv* env, jobject /* thiz */, jobject activity) {
    if (gRenderThread.joinable()) return JNI_TRUE;
    gStop.store(false);
    gActivity = env->NewGlobalRef(activity);
    Runtime runtime;
    if (!createInstanceAndSession(runtime, env, activity)) {
        destroy(runtime);
        env->DeleteGlobalRef(gActivity);
        gActivity = nullptr;
        return JNI_FALSE;
    }
    // EGL contexts are thread-affine: release it here and make it current on the render thread.
    eglMakeCurrent(runtime.display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
    gRenderThread = std::thread([runtime = std::move(runtime)]() mutable {
        renderLoop(runtime);
        destroy(runtime);
        JNIEnv* threadEnv = nullptr;
        if (gVm->AttachCurrentThread(&threadEnv, nullptr) == JNI_OK) {
            if (gActivity) threadEnv->DeleteGlobalRef(gActivity);
            gActivity = nullptr;
            gVm->DetachCurrentThread();
        }
    });
    return JNI_TRUE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_lvl_play_OpenXrActivity_nativeStop(JNIEnv*, jobject) {
    gStop.store(true);
    if (gRenderThread.joinable()) gRenderThread.join();
}
