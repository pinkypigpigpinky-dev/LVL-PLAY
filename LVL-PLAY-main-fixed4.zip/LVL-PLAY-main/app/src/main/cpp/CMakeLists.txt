cmake_minimum_required(VERSION 3.22.1)
project(livplay_openxr LANGUAGES CXX)

find_package(OpenXR REQUIRED CONFIG)

add_library(livplay_openxr SHARED openxr_runtime.cpp)
target_compile_features(livplay_openxr PRIVATE cxx_std_17)
target_compile_options(livplay_openxr PRIVATE -Wall -Wextra)
target_link_libraries(livplay_openxr PRIVATE
    OpenXR::openxr_loader
    android
    log
    EGL
    GLESv3
)
