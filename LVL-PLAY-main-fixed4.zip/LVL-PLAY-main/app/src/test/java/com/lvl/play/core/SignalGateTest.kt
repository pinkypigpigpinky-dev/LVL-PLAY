package com.lvl.play.core

import org.junit.Assert.assertEquals
import org.junit.Test

class SignalGateTest {
    private val trusted = setOf("contractors-approved-adapter")
    private fun signal(
        source: String = "contractors-approved-adapter",
        time: Long = 9_900L,
        confidence: Float = 0.95f
    ) = GameSignal(source, "event-1", time, confidence, "test-event")

    @Test fun acceptsFreshHighConfidenceTrustedSignal() {
        assertEquals(SignalDecision.ACCEPT, SignalGate.evaluate(signal(), trusted, 10_000L))
    }

    @Test fun rejectsUnknownSource() {
        assertEquals(SignalDecision.REJECT_UNKNOWN_SOURCE,
            SignalGate.evaluate(signal(source = "unknown"), trusted, 10_000L))
    }

    @Test fun rejectsStaleSignal() {
        assertEquals(SignalDecision.REJECT_STALE,
            SignalGate.evaluate(signal(time = 9_000L), trusted, 10_000L))
    }

    @Test fun rejectsFutureTimestamp() {
        assertEquals(SignalDecision.REJECT_STALE,
            SignalGate.evaluate(signal(time = 10_001L), trusted, 10_000L))
    }

    @Test fun rejectsLowConfidence() {
        assertEquals(SignalDecision.REJECT_LOW_CONFIDENCE,
            SignalGate.evaluate(signal(confidence = 0.4f), trusted, 10_000L))
    }

    @Test fun rejectsMalformedConfidence() {
        assertEquals(SignalDecision.REJECT_INVALID,
            SignalGate.evaluate(signal(confidence = Float.NaN), trusted, 10_000L))
    }
}
