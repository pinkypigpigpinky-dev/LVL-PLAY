# LIV PLAY — 0.3.0 local tactical coach milestone

## Implemented in source

- Voice recognition results now flow into an offline tactical coaching engine.
- The engine provides transparent rule-based guidance for aim, positioning, rocket-jump planning, low-health survival, and situation assessment.
- The coach remembers short loadout and strategy notes in app-private SharedPreferences on the Quest device.
- Replies are displayed in the app and spoken through the installed offline Android TTS voice when available.
- PCVR remains a separate Windows/SteamVR desktop-mirror experiment.

## Not complete

- The coach is deterministic rules-based logic, not a bundled local neural language model.
- Quest does not have a supported live view of Contractors' private render output, so it cannot place verified enemy markers without a permitted game data source.
- PCVR motion regions are not enemy recognition; semantic detection needs a local model and labeled gameplay evaluation.
- Cross-device memory sync, full editable memory management, wake-word operation, continuous turn-taking, and true open-ended reasoning are not implemented.
- No successful APK build, physical Quest install, or headset performance validation has been confirmed.

## Next engineering gates

1. Run Android unit tests and assemble the debug APK in CI.
2. Add tests for tactical prompt classification and memory behavior.
3. Verify voice input-to-response-to-TTS on a real Quest with network disabled.
4. Add a bundled, properly licensed quantized local language model only after selecting a Quest-compatible runtime and measuring RAM/thermal costs.
5. Improve PCVR visual detection with a packaged local model, labeled Contractors clips, confidence calibration, and false-alert reporting.
6. Keep game integration optional and use only a permitted documented source.
7. Validate the HUD separately; the existing OpenXR panel is inside LIV PLAY's own app session, not over Contractors.

## Safety/privacy invariants

- No external AI or cloud speech provider.
- No unsupported Quest cross-app capture or universal overlay.
- No hidden game-state access, process injection, memory reading, or anti-cheat bypass.
- The coach must say when it cannot see the game and must never invent enemy coordinates.
- Local tactical notes remain on-device.
