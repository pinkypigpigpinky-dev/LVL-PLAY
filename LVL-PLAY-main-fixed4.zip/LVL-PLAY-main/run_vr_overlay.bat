@echo off
cd /d "%~dp0"
if not exist .venv (py -3 -m venv .venv)
call .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements-vr.txt
python vr_overlay.py
pause
