# LIV PLAY intelligence architecture — 0.3.0

## Product direction

LIV PLAY supports two complementary modes, with standalone Meta Quest as the primary target:

1. **Quest standalone coach:** runs locally on the headset. It accepts player-provided voice context, gives tactical coaching, and stores short tactical preferences in app-private storage. It does not need a Contractors integration to provide this form of coaching.
2. **PCVR visual coach:** a separate Windows + SteamVR companion analyzes an explicitly selected desktop mirror locally. It can track visible motion and, once a compatible local vision model is installed and validated, classify objects that are actually visible in the captured frames.

The optional Contractors event adapter remains an enhancement. It can provide structured positions and events if a permitted game-side API becomes available, but neither coaching mode depends on it for its baseline functionality.

## What is implemented in source now

- Local Android TTS selects an installed voice that reports no network requirement.
- Android on-device speech recognition is used only when the OS exposes that capability.
- Recognized speech is passed into a deterministic local tactical coach.
- The first coach covers basic positioning, cover, health, aim/Direct Hit fundamentals, and rocket-jump preparation.
- The coach can save and retrieve short loadout and strategy notes in app-private SharedPreferences.
- The player can ask LIV to clear saved tactical notes.
- The UI displays the recognized utterance and LIV's response.
- The PCVR prototype remains separate and uses a desktop mirror, OpenVR overlay, and OpenCV motion tracking.

## Honest capability boundaries

### Quest standalone

A normal Android/Quest application is sandboxed from unrelated immersive games. LIV does not have a supported universal method to inspect Contractors' private framebuffer or draw a marker into its render pass. Therefore:
- LIV can coach from player-described situations and remembered preferences.
- LIV cannot claim it sees enemy positions, teams, projectiles, health, or rocket-jump state.
- It cannot show truthful live enemy markers without a permitted game-side data source or a documented platform capability.
- No screen scraping, hidden compositor access, process injection, memory reading, or anti-cheat bypass is used.

### PCVR

The Windows experiment captures a user-selected desktop monitor mirror and draws a head-locked OpenVR overlay. The current detector finds generic motion regions. It does not know whether a region is an enemy, teammate, projectile, or visual effect. Semantic classification requires a suitable local model, labeled gameplay evaluation, and performance testing. It must not display a generic motion blob as a confirmed enemy.

## Intelligence roadmap

### Stage A — Quest coach foundation (current)
- On-device voice in/out where offline system services exist.
- Local tactical rule engine.
- User-controlled local tactical notes.
- Explicit uncertainty when live game information is unavailable.

### Stage B — Better local reasoning
- Package an appropriately licensed quantized language model for ARM64, subject to Quest memory, thermal, and latency benchmarks.
- Build a bounded inference service that runs independently from OpenXR rendering.
- Add structured tactical context (class, loadout, health, map, objective, role) with explicit user confirmation.
- Add a retrieval layer over user-authored notes and approved local game manuals.
- Keep all inference and memory local; no external AI provider, hosted endpoint, or mandatory cloud account.

A bundled language model is not yet present in this repository. Do not label the current deterministic rules engine as a general-purpose LLM.

### Stage C — PCVR visual perception
- Make capture source selection explicit and verify the selected monitor/window.
- Improve frame queueing: bounded queue, newest-frame preference, and dropped-frame counters.
- Add local model loading with a pinned model path and clear model/license metadata.
- Separate object detection, tracking, and tactical interpretation.
- Track confidence and temporal consistency; expire stale tracks.
- Distinguish visible object categories only when the model is trained and evaluated for the actual game visuals.
- Calibrate screen coordinates and overlay alignment.
- Evaluate precision, recall, false positives, ID switches, and source-to-HUD latency on recorded Contractors sessions.

### Stage D — Shared tactical model
- Use a shared event vocabulary for player-described observations, visual observations, and optional approved game events.
- Every observation carries source, timestamp, confidence, and freshness.
- The reasoning layer receives only validated observations and cannot invent unseen entities.
- Voice callouts are concise, prioritized, interruptible, and suppress duplicate low-value alerts.
- The Quest and PCVR modes share tactics and memory concepts, but do not pretend they share live sensing capabilities.

## Data and privacy

- Quest tactical notes are stored in app-private preferences on the headset.
- The current notes are short strings, not a full cross-device account or encrypted sync system.
- No external AI provider or cloud speech service is part of this implementation.
- The PCVR vision prototype processes frames locally on the Windows machine.
- Raw video/audio retention should remain disabled unless a separately explained, user-enabled recording feature is implemented.
- User must be able to inspect and clear locally stored tactical notes.

## Release gates

This source change is not a tested APK or a production-ready tactical assistant. Before release:
1. Build and unit-test Android source in CI.
2. Install on physical Quest hardware and test offline voice input/output.
3. Measure model memory, inference latency, thermal impact, and battery drain before selecting a local LLM.
4. Validate PCVR capture and overlay on the target SteamVR setup.
5. Build a labeled Contractors gameplay dataset with permission and evaluate vision performance.
6. Test false-positive suppression, stale-data handling, and disconnect behavior.
7. Confirm all advertised capabilities on actual target devices.

## Current milestone status

**0.3.0 source milestone:** local voice-to-coach loop and app-private tactical preference notes have been added. The Quest build, device behavior, and PCVR overlay have not been validated by this change. No local LLM, semantic enemy detector, true cross-device memory sync, or live Quest game overlay is included yet.
