# LIV PLAY — Quest-first dual-platform architecture

**Priority: standalone Meta Quest. Secondary path: PCVR visual analysis.**

## Product promise

LIV should remain useful without a Contractors game integration. The standalone Quest app provides offline voice conversation, situation-based tactical guidance, and local player-preference memory. Game integration is optional: it adds exact events and coordinates when a permitted source exists, but it is not required for basic coaching.

The PCVR path is separate: a Windows/SteamVR tool analyzes an explicitly selected desktop game mirror locally. It can currently detect generic motion regions, not reliably identify enemies.

## Standalone Quest capabilities and limits

A normal standalone Android/Quest app is sandboxed from other apps. LIV does not assume it can read another game's private framebuffer, inspect its internal state, or draw arbitrary world-locked markers into its render pass. Meta's OpenXR and Spatial SDK APIs are for an app's own immersive experience and spatial panels; they are not a universal overlay API over unrelated games.

Quest mode can:
- Listen through an explicitly started on-device speech-recognition session.
- Speak through an installed offline Android TTS voice.
- Give deterministic tactical suggestions based on the player's description.
- Remember short loadout and strategy notes in app-private local preferences.
- Consume optional, permitted game events through the Contractors adapter boundary.

Quest mode cannot, without a supported source:
- Identify live enemy locations from Contractors' private rendered output.
- Draw live enemy markers over the standalone Contractors app.
- Know hidden enemy positions, health, class, weapons, or projectile state.

## PCVR visual-analysis path

The legacy Windows/SteamVR experiment captures a selected desktop mirror with local screen-capture software, performs OpenCV motion segmentation and track association, and draws generic motion-region markers. It is a separate PCVR workflow and is not a Quest standalone capability.

Future PCVR work can add a local object-detection model, HUD/text parsing, temporal tracking, and tactical inference. A detection must be described according to what the model actually recognizes; generic movement must never be labeled an enemy. Use only authorized capture sources and respect game/server rules.

## Offline tactical coach

The current Quest coach is a deterministic, transparent rule engine. It recognizes a small set of tactical topics (positioning, aim, rocket jumps, low health, threats, and preferences), returns concise advice, and stores short loadout/strategy notes locally. It is a functional first voice-to-coach loop, not a bundled neural language model or open-ended general intelligence.

A future bundled local model can improve flexible reasoning without sending data to an external provider. That requires selecting a model license, quantization, memory footprint, inference runtime, and performance targets for the actual Quest hardware. Do not claim that model is present until its weights and runtime are packaged and tested.

## Optional game integration

A permitted Contractors-side adapter is an enhancement, not a prerequisite for coaching. If a game or mod legitimately exposes player-visible events, entity transforms, weapon/projectile state, and timing, LIV can consume those through a versioned event schema. The adapter must report missing fields; it must not fabricate them.

## Local memory and privacy

- Keep preferences on the headset in app-private storage.
- Store only explicit, useful player notes; support review, editing, export, and clearing as the memory feature matures.
- Do not upload gameplay, voice, or personal memory to an external AI provider.
- Do not retain raw audio/video unless the user explicitly enables a feature that needs it.
- No external AI or cloud speech provider is required.

## Reliability

- Keep perception and rendering independent.
- Use source, timestamp, confidence, and freshness for any live claim.
- Distinguish confirmed, probable, and unknown.
- Expire stale tracks and stop tactical claims when the source disconnects.
- Measure latency, false alerts, missed detections, thermal impact, and frame timing on real devices.
- No hidden APIs, private compositor access, process injection, game-memory reading, or anti-cheat bypass.

## Release gates

1. Build reproducibly and run unit tests.
2. Install and test on physical Quest hardware with network disabled.
3. Verify local voice input/output and local memory persistence.
4. Profile CPU/GPU, thermals, battery, and app lifecycle during sustained play.
5. Validate PCVR visual detections on labeled footage and measure precision/recall.
6. Verify optional game integration only through a permitted, documented interface.
7. Do not describe source scaffolding as a finished or tested product.


## Quest cross-app HUD panel (first implementation)

The app now declares a dedicated `HudOverlayActivity` using Meta Horizon OS's documented hybrid-app overlay launcher route:

- It is a 2D panel activity (`com.oculus.intent.category.2D`) with `com.oculus.intent.category.OVERLAY_LAUNCHER`.
- The manifest declares the Horizon OS hybrid-app SDK metadata (minimum Horizon OS SDK 69).
- When LIV PLAY is launched from the Horizon OS overlay launcher while another immersive app is running, Horizon OS can show this panel over that immersive app. The panel has local Show/Hide controls and an explicitly labeled marker-style preview.
- The preview marker is **demo-only**. The panel currently reports “NOT CONNECTED” and draws no enemy targets as real detections.

This is a supported first step toward an Iron Man-style HUD, but it is not yet the final experience: Horizon's hybrid-app docs describe an overlay *panel* activity, not a third-party transparent 3D layer injected into the game's render pass. Horizon OS also assigns input focus to one app at a time; when the panel owns focus, Contractors may continue rendering but may not receive controller input until focus returns. Therefore this panel is a coexistence/UX prototype, not yet a passive HUD that lets you keep controlling Contractors uninterrupted. It does not automatically receive Contractors' framebuffer, entity coordinates, or depth. Exact enemy boxes, directional brackets, confidence, and range require a permitted live data provider from the game or an official integration/mod API. Until that exists, the app must show no live enemy markers rather than invent targets.

To test panel coexistence on a headset: install LIV PLAY, launch Contractors, open the Horizon OS system/overlay launcher while Contractors is active, and launch LIV PLAY from that overlay launcher. Confirm that the panel appears without exiting Contractors, then test Show/Hide and the clearly labeled demo preview. This is a physical Quest test and has not yet been performed by CI.

The older right-A triple-tap binding remains only for LIV PLAY's own OpenXR session; it cannot toggle the separate panel while Contractors owns focus.
