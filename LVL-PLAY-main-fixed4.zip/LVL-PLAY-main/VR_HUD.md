# LIV PLAY — in-headset HUD prototype

This is the separate VR overlay path. It does not require the browser to remain open.

## Windows + SteamVR quick start

1. Install Python 3.11+ and SteamVR.
2. Launch SteamVR and start Contractors VR.
3. Make sure the game mirror is visible on a desktop monitor. For best alignment, use a fullscreen/borderless mirror on the primary monitor.
4. Double-click `run_vr_overlay.bat`.
5. LIV PLAY creates a transparent OpenVR overlay in the headset. The desktop console can be minimized; leave the Python process running.
6. Press Ctrl+C in its console to stop the overlay.

Optional environment variables (PowerShell, before launching):
- `$env:LIV_PLAY_MONITOR="1"` — mss monitor index (1 is primary display; 0 is all monitors).
- `$env:LIV_PLAY_FPS="15"` — analysis/update target (5–30).
- `$env:LIV_PLAY_HUD_WIDTH="2.25"` — overlay width in meters.
- `$env:LIV_PLAY_HUD_DISTANCE="1.35"` — distance in front of the HMD.

## What this HUD actually does

- Uses OpenVR's overlay compositor to place a transparent HUD in the headset over the running VR scene.
- Captures a desktop monitor locally using mss.
- Uses OpenCV background subtraction, contour detection and centroid tracking to draw motion-region boxes and short-horizon image-space lead dots.
- The overlay process is independent of the browser dashboard.

## Important limitations (not yet game intelligence)

This first headset overlay is a working **motion HUD prototype**, not a completed TF2 coach:
- It labels moving regions, not confirmed players/enemies/classes/weapons.
- It does not detect rocket-jump preparation or understand TF2 game state.
- Its lead dots are image-space extrapolations, not calibrated Direct Hit aim solutions.
- It places a head-locked transparent HUD plane in front of the scene. It does not yet attach markers to world-space enemy positions or correct for the VR game's per-eye projection/distortion. Exact world-locked markers need a supported game telemetry/mod integration or a proper OpenXR/SteamVR scene-aware integration.
- A visible desktop mirror is required for this capture implementation. Some VR runtimes/games do not expose a mirror or may show a spectator view rather than the player's exact eye view.

Do not use the prototype in ways that violate server rules or anti-cheat policy. It does not inject into or modify Contractors.
