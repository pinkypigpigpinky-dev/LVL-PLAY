$ErrorActionPreference = "Stop"
# Native SDK tools emit compatibility warnings on stderr; do not treat warnings as fatal.
$PSNativeCommandUseErrorActionPreference = $false
Set-StrictMode -Version Latest
function Write-Step([string]$Message) { Write-Host ([Environment]::NewLine + "==> " + $Message) -ForegroundColor Cyan }
function Require-Command([string]$Name, [string]$Hint) {
    if (-not (Get-Command $Name -ErrorAction SilentlyContinue)) { throw "$Name was not found. $Hint" }
}
$RepoRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$ToolsRoot = Join-Path $env:LOCALAPPDATA "LIV-PLAY-build-tools"
$SdkRoot = Join-Path $env:LOCALAPPDATA "Android\Sdk"
$GradleVersion = "8.11.1"
$GradleHome = Join-Path $ToolsRoot "gradle-$GradleVersion"
$GradleZip = Join-Path $ToolsRoot "gradle-$GradleVersion-bin.zip"
$CmdlineZip = Join-Path $ToolsRoot "android-commandlinetools.zip"
$CmdlineRoot = Join-Path $SdkRoot "cmdline-tools\latest"
$CmdlineArchiveId = "15859902"
$CmdlineMarker = Join-Path $CmdlineRoot ".liv-tools-archive-id"
New-Item -ItemType Directory -Force -Path $ToolsRoot, $SdkRoot | Out-Null
Write-Step "Checking Java 17"
function Test-Java17([string]$JavaExe) {
    if (-not (Test-Path $JavaExe)) { return $false }
    $outFile = Join-Path $env:TEMP ("liv-java-out-" + [guid]::NewGuid().ToString("N") + ".txt")
    $errFile = Join-Path $env:TEMP ("liv-java-err-" + [guid]::NewGuid().ToString("N") + ".txt")
    try {
        $p = Start-Process -FilePath $JavaExe -ArgumentList "-version" -NoNewWindow -Wait -PassThru -RedirectStandardOutput $outFile -RedirectStandardError $errFile
        $v = ((Get-Content $outFile -Raw -ErrorAction SilentlyContinue) + "`n" + (Get-Content $errFile -Raw -ErrorAction SilentlyContinue))
        return ($v -match 'version\s+"17(?:\.|")')
    } finally {
        Remove-Item $outFile, $errFile -Force -ErrorAction SilentlyContinue
    }
}
function Find-Java17 {
    $candidates = @()
    $cmd = Get-Command java.exe -ErrorAction SilentlyContinue
    if ($cmd -and $cmd.Source) { $candidates += $cmd.Source }
    foreach ($root in @(
        (Join-Path $env:ProgramFiles "Eclipse Adoptium"),
        (Join-Path $env:ProgramFiles "Microsoft"),
        (Join-Path $env:ProgramFiles "Java"),
        (Join-Path $env:ProgramFiles "Amazon Corretto"),
        (Join-Path $env:LOCALAPPDATA "Programs\Eclipse Adoptium")
    )) {
        if (Test-Path $root) {
            $candidates += Get-ChildItem $root -Filter java.exe -File -Recurse -ErrorAction SilentlyContinue |
                Where-Object { $_.FullName -match 'jdk[-_]?17|jdk-17|17\.' } |
                Select-Object -ExpandProperty FullName
        }
    }
    foreach ($candidate in ($candidates | Select-Object -Unique)) {
        if (Test-Java17 $candidate) { return $candidate }
    }
    return $null
}
$javaExe = Find-Java17
if (-not $javaExe) {
    Require-Command "winget" "Install Windows App Installer, then run this script again."
    Write-Host "Java 17 was not found. Installing Eclipse Temurin JDK 17..."
    & winget install --id EclipseAdoptium.Temurin.17.JDK --exact --silent --accept-package-agreements --accept-source-agreements
    # winget can report that an installed package has no upgrade available. Verify
    # the actual Java executable rather than treating that message as a fatal error.
    $javaExe = Find-Java17
    if (-not $javaExe) {
        throw "Java 17 was not found after the installer ran. Install or repair a JDK 17, then rerun this script."
    }
}
$javaBin = Split-Path $javaExe -Parent
$env:JAVA_HOME = Split-Path $javaBin -Parent
$env:Path = $javaBin + ";" + $env:Path
Write-Host "Using Java: $javaExe"
& $javaExe -version
Write-Step "Preparing Gradle $GradleVersion"
$GradleExe = Join-Path $GradleHome "bin\gradle.bat"
if (-not (Test-Path $GradleExe)) {
    Invoke-WebRequest -Uri "https://services.gradle.org/distributions/gradle-$GradleVersion-bin.zip" -OutFile $GradleZip
    $extract = Join-Path $ToolsRoot "gradle-extract"
    if (Test-Path $extract) { Remove-Item $extract -Recurse -Force }
    Expand-Archive -Path $GradleZip -DestinationPath $extract -Force
    Move-Item -Path (Join-Path $extract "gradle-$GradleVersion") -Destination $GradleHome -Force
    Remove-Item $extract -Recurse -Force
}
Write-Step "Preparing Android SDK command-line tools"
$sdkManager = Join-Path $CmdlineRoot "bin\sdkmanager.bat"
$installedArchiveId = if (Test-Path $CmdlineMarker) { (Get-Content $CmdlineMarker -Raw).Trim() } else { "" }
if (-not (Test-Path $sdkManager) -or $installedArchiveId -ne $CmdlineArchiveId) {
    Write-Host "Installing current Android command-line tools..."
    Invoke-WebRequest -Uri "https://dl.google.com/android/repository/commandlinetools-win-$($CmdlineArchiveId)_latest.zip" -OutFile $CmdlineZip
    $expectedSha256 = "90ae805d20434428bffcb699c290860f19bb5f66a67e6b330067e3de801fb04a"
    $actualSha256 = (Get-FileHash -Path $CmdlineZip -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actualSha256 -ne $expectedSha256) { throw "Android command-line tools checksum mismatch. Download was not installed." }
    $temp = Join-Path $ToolsRoot "android-cmdline-extract"
    if (Test-Path $temp) { Remove-Item $temp -Recurse -Force }
    New-Item -ItemType Directory -Force -Path $temp | Out-Null
    Expand-Archive -Path $CmdlineZip -DestinationPath $temp -Force
    if (Test-Path $CmdlineRoot) { Remove-Item $CmdlineRoot -Recurse -Force }
    New-Item -ItemType Directory -Force -Path $CmdlineRoot | Out-Null
    Copy-Item -Path (Join-Path $temp "cmdline-tools\*") -Destination $CmdlineRoot -Recurse -Force
    Set-Content -Path $CmdlineMarker -Value $CmdlineArchiveId -Encoding ASCII
    Remove-Item $temp -Recurse -Force
}
$sdkManager = Join-Path $CmdlineRoot "bin\sdkmanager.bat"
$env:ANDROID_HOME = $SdkRoot
$env:ANDROID_SDK_ROOT = $SdkRoot
$env:Path = (Join-Path $CmdlineRoot "bin") + ";" + (Join-Path $SdkRoot "platform-tools") + ";" + $env:Path
Write-Step "Accepting Android SDK licences"
# Windows PowerShell 5.1 can turn sdkmanager stderr warnings into terminating
# NativeCommandError records even when sdkmanager exits successfully. Capture
# stderr to a file so warnings remain diagnostic text, not PowerShell failures.
$licenseErr = Join-Path $ToolsRoot "sdkmanager-licenses-stderr.txt"
$licenseOutput = 1..40 | ForEach-Object { "y" } | & $sdkManager "--sdk_root=$SdkRoot" --licenses 2> $licenseErr
$licenseExit = $LASTEXITCODE
if (Test-Path $licenseErr) { Get-Content $licenseErr | ForEach-Object { Write-Host $_ -ForegroundColor DarkYellow } }
if ($licenseExit -ne 0) { $licenseOutput | ForEach-Object { Write-Host $_ }; throw "Android SDK licence setup failed (sdkmanager exit code $licenseExit)." }
Write-Step "Installing Android 35, Build Tools, CMake and NDK"
$sdkInstallErr = Join-Path $ToolsRoot "sdkmanager-install-stderr.txt"
$sdkInstallOutput = & $sdkManager "--sdk_root=$SdkRoot" "platform-tools" "platforms;android-35" "build-tools;35.0.0" "cmake;3.22.1" "ndk;27.2.12479018" 2> $sdkInstallErr
$sdkInstallExit = $LASTEXITCODE
$sdkInstallOutput | ForEach-Object { Write-Host $_ }
if (Test-Path $sdkInstallErr) { Get-Content $sdkInstallErr | ForEach-Object { Write-Host $_ -ForegroundColor DarkYellow } }
if ($sdkInstallExit -ne 0) { throw "Android SDK package installation failed (sdkmanager exit code $sdkInstallExit)." }
Write-Step "Checking native build prerequisites"
Require-Command "tar" "Windows 10/11 includes tar.exe. Install a current Windows update if it is missing."
Write-Step "Writing local Android SDK path"
$sdkPath = $SdkRoot.Replace("\", "/")
Set-Content -Path (Join-Path $RepoRoot "local.properties") -Value "sdk.dir=$sdkPath" -Encoding ASCII
Write-Step "Building the LIV PLAY Quest APK"
Push-Location $RepoRoot
try {
    & $GradleExe --no-daemon --stacktrace :app:assembleDebug
    if ($LASTEXITCODE -ne 0) { throw "Gradle build failed (exit code $LASTEXITCODE). Scroll up to the first error." }
} finally { Pop-Location }
$apk = Join-Path $RepoRoot "app\build\outputs\apk\debug\app-debug.apk"
if (-not (Test-Path $apk)) { throw "Gradle reported success, but the expected APK was not found at $apk." }
$dist = Join-Path $RepoRoot "dist"
New-Item -ItemType Directory -Force -Path $dist | Out-Null
$finalApk = Join-Path $dist "LIV-PLAY-Quest-debug.apk"
Copy-Item $apk $finalApk -Force
Write-Step "Build complete"
Write-Host "APK: $finalApk" -ForegroundColor Green
Write-Host "Install it on the Quest using Meta Quest Developer Hub or adb after enabling developer mode."
