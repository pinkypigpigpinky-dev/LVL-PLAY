# LVL PLAY

LIV-powered gaming companion. **Primary target: standalone Meta Quest, with a separate PCVR visual-analysis path.**

## Quest app — 0.5.0 development milestone

The Android app now includes a separate Quest Visual Lab with local TensorFlow Lite object detection (user-supplied model), multi-frame tracking, coarse camera-shift compensation, confidence-aware scene summaries, and local visual memory connected to LIV's coach. Screenshot and imported video analysis run on-device.

- [QUEST_APP.md](QUEST_APP.md) — build/install instructions and implementation boundaries.
- [QUEST_STANDALONE.md](QUEST_STANDALONE.md) — Quest-first architecture, reliability requirements, and optional Contractors integration.
- [QUEST_VISUAL_LAB.md](QUEST_VISUAL_LAB.md) — separate Quest-first visual-analysis subsystem, usage, limits, and roadmap.
- [Quest Visual Lab activity](app/src/main/java/com/lvl/play/vision/QuestVisionActivity.kt) — local screenshot/video import and analysis UI.
- [Visual frame analyzer](app/src/main/java/com/lvl/play/vision/VisualFrameAnalyzer.kt) — on-device grid features and frame-change analysis.
- [Local object detector](app/src/main/java/com/lvl/play/vision/LocalObjectDetector.kt) — TensorFlow Lite Task Vision adapter.
- [Visual tracking](app/src/main/java/com/lvl/play/vision/VisualTracking.kt) — multi-frame association and coarse camera-motion compensation.
- [Visual tactical memory](app/src/main/java/com/lvl/play/vision/VisualTacticalMemory.kt) — confidence-aware assessment and local observation history.
- [Local tactical coach](app/src/main/java/com/lvl/play/coach/TacticalCoach.kt)
- [Local LIV speech](app/src/main/java/com/lvl/play/speech/LocalLivSpeech.kt)
- [OpenXR native runtime](app/src/main/cpp/openxr_runtime.cpp)
- [Contractors adapter boundary](app/src/main/java/com/lvl/play/contractors/ContractorsAdapter.kt)

**Important:** this is source code, not a verified APK or headset-tested release. The first tactical coach is deterministic rule-based logic, not a bundled neural language model. The Quest app does not see another game's private render output or draw live markers over Contractors.

## Build the Quest APK on Windows

GitHub Actions is not required. Download or clone the repository on Windows and double-click `Build-LIV-Quest.bat`. The script prepares JDK 17, Gradle, Android SDK command-line tools, CMake, and NDK, then builds the debug APK locally. See [BUILD_WINDOWS.md](BUILD_WINDOWS.md). Output: `dist/LIV-PLAY-Quest-debug.apk`. This is a development/test APK, not a signed release. The current Visual Lab supports separate general and game-specific local detector slots; model weights are not bundled.

## Two operating modes

- **Standalone Quest (priority):** voice conversation, local tactical advice based on what the player describes, and locally saved loadout/strategy preferences. Imported-footage visual analysis is now available in the Quest Visual Lab; live visual enemy tracking still requires a permitted game data source.
- **PCVR:** the separate Windows + SteamVR prototype can analyze an authorized desktop game mirror locally and display motion-region indicators. It does not currently identify enemies or classes. A suitable local vision model and labeled gameplay validation are needed for semantic recognition.

## Platform and privacy boundaries

- Local processing; no external AI or cloud speech provider dependency.
- No unsupported Quest cross-app screen capture or universal overlay.
- No hidden APIs, process injection, game-memory reading, or anti-cheat bypass.
- Game integration is optional for basic coaching and only adds precision when a permitted source exists.
- Do not claim a feature is reliable until it passes build, physical-device, and gameplay validation.

## Legacy experiments

The browser dashboard and Python/OpenVR tools remain development experiments, not required components of the standalone Quest coach. The PCVR overlay requires Windows, SteamVR, and a visible desktop mirror.

- [Contractors dataset protocol and model-training gates](tools/contractors_vision/DATASET_SCHEMA.md) — rights-first capture, annotation classes, split rules, export and Quest acceptance criteria.
- [Local vision toolchain](tools/contractors_vision/README.md) — frame extraction, manual annotation, external YOLO dataset import, local training, evaluation, and Quest release gates.\n- [Dataset validator](tools/contractors_vision/validate_dataset.py) — standard-library checks for YOLO labels, provenance fields, paired files, and split leakage.
