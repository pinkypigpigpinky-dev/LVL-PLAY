# LIV PLAY Quest app — 0.3.0 development milestone

## What is implemented in source

- Kotlin/Compose setup interface and native OpenXR lifecycle foundation.
- Local-only Android TextToSpeech voice selection and Android on-device speech recognition.
- Voice loop: recognized player speech is passed to LIV's offline tactical coach; the response is displayed and spoken using the installed offline TTS voice when available.
- Deterministic tactical coaching rules for positioning, aim, rocket-jump planning, low-health survival, and situational prompts.
- Local tactical preference memory: short loadout and strategy notes are stored in app-private SharedPreferences on the headset.
- Optional Contractors event-source adapter boundary with freshness/confidence validation.

## What Quest mode can do without game integration

The standalone coach can advise based on player-described situations, answer basic tactical prompts, and remember loadout/strategy notes locally. The coaching core does not require a Contractors mod or telemetry connection.

It cannot see Contractors' private rendered frames, inspect game memory, identify live enemies from another app, or draw arbitrary live markers over that game's immersive view. A supported game-side event source would add precise positions and events; it is optional for conversational coaching.

## PCVR path

The separate Windows/SteamVR prototype captures an explicitly selected desktop mirror locally and can render generic motion-region indicators. It is an experimental companion path, not part of the Quest Android runtime. Generic motion is not proof of an enemy. Semantic detection requires a suitable local model, model packaging, labeled game footage, and measured false-positive/false-negative performance.

## Current limitations

- The tactical coach is a transparent deterministic rules engine, **not yet a bundled local language model**. It is not open-ended human-level reasoning.
- Saved memory currently covers only short loadout and strategy notes; no cross-device sync is implemented.
- The Quest HUD is still a demo within LIV PLAY's own OpenXR session, not a HUD over Contractors.
- No APK build or physical Quest installation/performance test has been confirmed.
- The PCVR motion tracker has not been validated as enemy recognition.
- No Contractors mod/plugin is connected.

## Build

Requirements: Android Studio, SDK Platform 35, JDK 17, Android NDK, CMake 3.22.1, and a Quest with Developer Mode/USB debugging for installation.

```bash
gradle :app:testDebugUnitTest :app:assembleDebug
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

The repository does not currently include a Gradle wrapper. Build/test success must be verified in CI or Android Studio; source commits alone do not establish a working APK.

## Privacy and reliability

- No external AI or cloud speech provider.
- No unsupported cross-app capture, hidden game-state access, process injection, or anti-cheat bypass.
- Only the explicit local preference notes are persisted by the tactical coach.
- When live game data is absent, LIV must state that it cannot see the game rather than inventing enemy locations.


## Quest Visual Lab — 0.4.0

The home screen now launches a separate `QuestVisionActivity` visual-analysis workspace. It uses Android's system document picker to import an image or video selected by the user. Processing happens locally:
- Screenshots are scaled to a maximum 640-pixel long edge and analyzed for coarse luminance and edge structure.
- Videos are sampled at up to ten timestamps. Adjacent sampled frames are compared and aggregated into an 8×6 change map.
- The map shows measured pixel changes only; it does not classify enemies, teammates, weapons, or threats.
- The visual lab does not request camera, microphone, screen-recording, or network permissions.

See [QUEST_VISUAL_LAB.md](QUEST_VISUAL_LAB.md) for how to test it and the planned semantic-vision stages. It is a source-code prototype; build and physical Quest validation remain outstanding.


## Quest Visual Lab — 0.5.0

The separate visual-analysis activity now supports:
- Importing a compatible local TensorFlow Lite Task Vision `.tflite` object detector (model weights are not bundled).
- Running local detection on screenshots and up to ten sampled video frames.
- Displaying model labels, confidence, bounding-box coordinates, and track persistence.
- Associating same-label boxes across frames using IoU.
- Estimating coarse 2D camera translation from downsampled frame matching.
- Saving bounded visual observation history in app-private preferences.
- Connecting the latest summary to LIV's coach: ask **"What did you see?"**. Say **"Clear visual memory"** to clear the saved history and latest summary.

A general-purpose model is not trained for Contractors-specific weapons, teams, or enemy identity. See [QUEST_VISUAL_LAB.md](QUEST_VISUAL_LAB.md) for model requirements and validation limitations.
