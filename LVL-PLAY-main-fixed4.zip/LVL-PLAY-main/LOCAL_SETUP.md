# Run LIV PLAY locally

## Windows
1. Install Python 3.11 or newer.
2. Double-click `run.bat` (or run it from PowerShell).
3. Open http://127.0.0.1:8765 in Chrome or Edge.
4. Click **Start live capture** and choose the Contractors game window. Keep LIV PLAY in a separate browser window/monitor.

## macOS / Linux
Run `bash run.sh`, then open http://127.0.0.1:8765.

## What is genuinely local in this prototype
The browser asks you to share a screen/window. Frames are sent only to the Python service bound to 127.0.0.1 on this computer. OpenCV performs motion segmentation, centroid association, velocity estimation and short-horizon lead-point projection locally. No frames are sent to an AI provider.

## Semantic game recognition (next model step)
The prototype can optionally load a local Ultralytics YOLO model. Install the optional package with `pip install ultralytics`, then set `LIV_PLAY_MODEL` to the path of a compatible local model file before starting the server. A TF2 Contractors-specific model must be trained/evaluated on representative Contractors footage and label classes/players/projectiles as desired. A generic model or motion regions must not be treated as verified TF2 enemy recognition. No model weights are bundled or silently downloaded.

Windows PowerShell example:
`$env:LIV_PLAY_MODEL="C:\\models\\tf2-contractors.pt"; python server.py`

## Notes
- Screen capture is permission-based and must be started by the user each session.
- This is a browser companion; it does not draw into the VR game or inject into it.
- Motion prediction is a simple image-space extrapolation, not game-physics-aware rocket-jump prediction. TF2 weapon timing requires game-specific detection, calibration and validation.
- Use only in ways permitted by the game/server rules and anti-cheat policy.
