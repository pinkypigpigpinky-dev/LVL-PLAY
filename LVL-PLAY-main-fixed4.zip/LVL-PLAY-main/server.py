from __future__ import annotations
import asyncio, json, os, time
from collections import deque
from pathlib import Path
from typing import Any

import cv2
import numpy as np
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, JSONResponse
import uvicorn

ROOT = Path(__file__).resolve().parent
app = FastAPI(title="LIV PLAY Local Intelligence", docs_url=None, redoc_url=None)

class LocalVision:
    """Local motion segmentation + object association. Optional local YOLO model."""
    def __init__(self):
        self.bg = cv2.createBackgroundSubtractorMOG2(history=180, varThreshold=32, detectShadows=False)
        self.tracks: dict[int, dict[str, Any]] = {}
        self.next_id = 1
        self.last_ts = time.time()
        self.model = None
        self.model_error = None
        model_path = os.getenv("LIV_PLAY_MODEL", "").strip()
        if model_path:
            try:
                from ultralytics import YOLO
                if not Path(model_path).is_file():
                    raise FileNotFoundError(f"Model file not found: {model_path}")
                self.model = YOLO(model_path)
            except Exception as exc:
                self.model_error = str(exc)

    def analyze(self, frame: np.ndarray) -> dict[str, Any]:
        h, w = frame.shape[:2]
        now = time.time()
        dt = max(0.03, min(0.5, now - self.last_ts))
        self.last_ts = now
        detections = []
        mode = "local-motion"
        if self.model is not None:
            try:
                results = self.model.predict(frame, verbose=False, conf=0.35, imgsz=640)
                for result in results:
                    names = result.names
                    for box in result.boxes:
                        x1,y1,x2,y2 = [float(v) for v in box.xyxy[0].tolist()]
                        cls = int(box.cls[0])
                        detections.append({"x":(x1+x2)/2,"y":(y1+y2)/2,"w":x2-x1,"h":y2-y1,
                                           "label":str(names.get(cls, cls)), "confidence":float(box.conf[0])})
                mode = "local-yolo"
            except Exception as exc:
                self.model_error = str(exc)
        else:
            # Generic motion regions: useful for testing live capture and movement,
            # but not semantic enemy/class recognition.
            small = cv2.resize(frame, (640, max(1, int(h * 640 / w))))
            mask = self.bg.apply(small)
            mask = cv2.medianBlur(mask, 5)
            kernel = np.ones((5,5), np.uint8)
            mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
            mask = cv2.dilate(mask, kernel, iterations=2)
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            for c in contours:
                area = cv2.contourArea(c)
                if area < 420 or area > 180000:
                    continue
                x,y,bw,bh = cv2.boundingRect(c)
                scale = w / 640
                detections.append({"x":(x+bw/2)*scale,"y":(y+bh/2)*scale,
                                   "w":bw*scale,"h":bh*scale,"label":"moving region","confidence":0.0})

        # Nearest-centroid association keeps IDs stable across adjacent frames.
        unmatched = set(self.tracks.keys())
        output = []
        for det in detections:
            best, best_dist = None, 1e9
            for tid in list(unmatched):
                tr = self.tracks[tid]
                dist = float(np.hypot(det["x"]-tr["x"], det["y"]-tr["y"]))
                limit = max(65.0, 0.9 * max(det["w"], det["h"], tr["w"], tr["h"]))
                if dist < limit and dist < best_dist:
                    best, best_dist = tid, dist
            if best is None:
                tid = self.next_id; self.next_id += 1
                self.tracks[tid] = {**det, "vx":0.0, "vy":0.0, "seen":now}
            else:
                tid = best; unmatched.discard(tid)
                tr = self.tracks[tid]
                alpha = 0.55
                vx = (det["x"]-tr["x"])/dt
                vy = (det["y"]-tr["y"])/dt
                tr.update({**det, "vx":alpha*vx+(1-alpha)*tr["vx"],
                           "vy":alpha*vy+(1-alpha)*tr["vy"], "seen":now})
            tr = self.tracks[tid]
            px = float(np.clip(tr["x"] + tr["vx"]*0.32, 0, w))
            py = float(np.clip(tr["y"] + tr["vy"]*0.32, 0, h))
            speed = float(np.hypot(tr["vx"], tr["vy"]))
            output.append({"id":tid,"label":tr["label"],"confidence":round(float(tr.get("confidence",0)),2),
                           "x":round(tr["x"]/w,4),"y":round(tr["y"]/h,4),
                           "w":round(tr["w"]/w,4),"h":round(tr["h"]/h,4),
                           "vx":round(tr["vx"],1),"vy":round(tr["vy"],1),
                           "speed":round(speed,1),"lead_x":round(px/w,4),"lead_y":round(py/h,4)})
        for tid in list(unmatched):
            if now - self.tracks[tid]["seen"] > 0.8:
                del self.tracks[tid]
        events = []
        for item in output:
            if item["speed"] > 260:
                direction = "upward" if item["vy"] < -120 else "downward" if item["vy"] > 120 else "fast lateral"
                events.append({"kind":"movement","text":f'Track {item["id"]}: fast {direction} movement', "track_id":item["id"]})
        return {"type":"analysis","mode":mode,"width":w,"height":h,"tracks":output,
                "events":events,"model_error":self.model_error,"timestamp":now}

@app.get("/")
async def index():
    return FileResponse(ROOT / "index.html")

@app.get("/health")
async def health():
    return JSONResponse({"ok":True,"service":"LIV PLAY local vision","model_configured":bool(os.getenv("LIV_PLAY_MODEL")),
                         "capture":"browser-permission-required"})

@app.websocket("/ws/vision")
async def vision_socket(ws: WebSocket):
    await ws.accept()
    vision = LocalVision()
    try:
        while True:
            raw = await ws.receive_bytes()
            arr = np.frombuffer(raw, dtype=np.uint8)
            frame = cv2.imdecode(arr, cv2.IMREAD_COLOR)
            if frame is None:
                await ws.send_text(json.dumps({"type":"error","message":"Could not decode frame"}))
                continue
            # Bound CPU cost and keep aspect ratio.
            h,w = frame.shape[:2]
            if w > 960:
                frame = cv2.resize(frame, (960, int(h*960/w)))
            result = vision.analyze(frame)
            await ws.send_text(json.dumps(result))
    except WebSocketDisconnect:
        pass
    except Exception as exc:
        try: await ws.send_text(json.dumps({"type":"error","message":str(exc)}))
        except Exception: pass

if __name__ == "__main__":
    print("\nLIV PLAY is starting at http://127.0.0.1:8765")
    print("Open that address in your browser. Use Start capture and choose the Contractors game window.\n")
    uvicorn.run(app, host="127.0.0.1", port=8765, log_level="warning")
