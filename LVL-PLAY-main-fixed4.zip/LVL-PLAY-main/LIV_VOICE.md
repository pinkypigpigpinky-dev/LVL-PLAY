# LIV bundled voice

LIV's default speech voice is **Piper Alba**, a female British English voice. The ONNX voice model and eSpeak NG phonemizer data are bundled into the APK during the Gradle `preBuild` task. The build downloads pinned upstream release assets and verifies their SHA-256 hashes before packaging them, so speech synthesis works offline after installation and first initialization.

- Voice: Piper `en_GB-alba-medium-int8`
- Runtime: sherpa-onnx Android 2.0.1
- Inference: local CPU, two threads
- Voice model: int8 quantized medium model
- No network speech service is used.
- The model is copied from APK assets into the app-private files directory on first use.
- Speech recognition is a separate feature and still depends on an Android on-device recognition service being installed.

## Attribution and licensing

The Alba voice is distributed under Creative Commons Attribution 4.0 (CC BY 4.0). Retain the model's upstream model card and license attribution in the packaged assets. The sherpa-onnx runtime is distributed under its upstream project license; see the sherpa-onnx repository and release.

Upstream sources:
- Piper voice model archive: https://github.com/k2-fsa/sherpa-onnx/releases/tag/tts-models
- sherpa-onnx Android runtime: https://github.com/k2-fsa/sherpa-onnx/releases/tag/v2.0.1
- Piper voice model catalogue and model-specific licenses: https://github.com/rhasspy/piper-voices

The model is a synthetic speech voice, not a recording or clone of a specific person. “Young adult” is the intended persona direction, not a verified biographical attribute of the speaker.
